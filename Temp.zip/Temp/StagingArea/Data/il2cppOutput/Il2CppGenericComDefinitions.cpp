﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




