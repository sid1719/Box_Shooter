﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 UnityEngine.Material UnityStandardAssets.ImageEffects.Antialiasing::CurrentAAMaterial()
extern void Antialiasing_CurrentAAMaterial_m35A9DADF746986D8155C7B16699CC757DD9645EA ();
// 0x00000002 System.Boolean UnityStandardAssets.ImageEffects.Antialiasing::CheckResources()
extern void Antialiasing_CheckResources_m992294E535DD40C212A746ACAC3B4B890C6A5187 ();
// 0x00000003 System.Void UnityStandardAssets.ImageEffects.Antialiasing::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Antialiasing_OnRenderImage_mDAEAD8526443B85398951FB1AB482759C3D3230F ();
// 0x00000004 System.Void UnityStandardAssets.ImageEffects.Antialiasing::.ctor()
extern void Antialiasing__ctor_mEF11CF01265269B2A640833625EDA610C80E104D ();
// 0x00000005 System.Boolean UnityStandardAssets.ImageEffects.Bloom::CheckResources()
extern void Bloom_CheckResources_mC9CAC511BFD2007A470C8DCCB4048466EFBAF2CD ();
// 0x00000006 System.Void UnityStandardAssets.ImageEffects.Bloom::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Bloom_OnRenderImage_m92C9B1E77D73E8761AA9B976AF05DAA17F30A447 ();
// 0x00000007 System.Void UnityStandardAssets.ImageEffects.Bloom::AddTo(System.Single,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Bloom_AddTo_m35AF7DA3D13378B52D4AD626637F5A34C0FAAA51 ();
// 0x00000008 System.Void UnityStandardAssets.ImageEffects.Bloom::BlendFlares(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Bloom_BlendFlares_mF1A0DB8193EE254FC79CEF319993A87E441A219C ();
// 0x00000009 System.Void UnityStandardAssets.ImageEffects.Bloom::BrightFilter(System.Single,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Bloom_BrightFilter_m057C5D3B47D7AFB9B1ACAC512A465309E66CEB21 ();
// 0x0000000A System.Void UnityStandardAssets.ImageEffects.Bloom::BrightFilter(UnityEngine.Color,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Bloom_BrightFilter_mE98F787A51FA04D86D06850FF587CED2DD5DCF4E ();
// 0x0000000B System.Void UnityStandardAssets.ImageEffects.Bloom::Vignette(System.Single,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Bloom_Vignette_mB955F94B50143F8FF36BCE05CEFF197BA6D3453B ();
// 0x0000000C System.Void UnityStandardAssets.ImageEffects.Bloom::.ctor()
extern void Bloom__ctor_m671E3ABA13568745A5C1FA0A9528387C6C13F310 ();
// 0x0000000D System.Boolean UnityStandardAssets.ImageEffects.BloomAndFlares::CheckResources()
extern void BloomAndFlares_CheckResources_m4DCB928EB6919CB75CB6279E5C56D4921805A68F ();
// 0x0000000E System.Void UnityStandardAssets.ImageEffects.BloomAndFlares::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void BloomAndFlares_OnRenderImage_m863EF5506BE3DA81DAA863FD799DA2FFD287F836 ();
// 0x0000000F System.Void UnityStandardAssets.ImageEffects.BloomAndFlares::AddTo(System.Single,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void BloomAndFlares_AddTo_mD2B5CCC7CE591EF7788737C3B51601E7EAAA364D ();
// 0x00000010 System.Void UnityStandardAssets.ImageEffects.BloomAndFlares::BlendFlares(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void BloomAndFlares_BlendFlares_m10B4C8B7ED21842C3B3FE0B2E8490516B4794EF8 ();
// 0x00000011 System.Void UnityStandardAssets.ImageEffects.BloomAndFlares::BrightFilter(System.Single,System.Single,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void BloomAndFlares_BrightFilter_m3191A51782383B22BED4FB7DECF96F84FEFA41AA ();
// 0x00000012 System.Void UnityStandardAssets.ImageEffects.BloomAndFlares::Vignette(System.Single,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void BloomAndFlares_Vignette_m3ECA2114A2D5AB08DFA0EB013794639808A550A3 ();
// 0x00000013 System.Void UnityStandardAssets.ImageEffects.BloomAndFlares::.ctor()
extern void BloomAndFlares__ctor_mFBE9184D02B3D517C3FEB725127BE4775B8CB3FB ();
// 0x00000014 System.Boolean UnityStandardAssets.ImageEffects.BloomOptimized::CheckResources()
extern void BloomOptimized_CheckResources_mBE0B61C792C2E55D2D83A4D8E784F2810D3F02AA ();
// 0x00000015 System.Void UnityStandardAssets.ImageEffects.BloomOptimized::OnDisable()
extern void BloomOptimized_OnDisable_m01F98DF689CC1FA49D1649FAF6D9605DC58191A3 ();
// 0x00000016 System.Void UnityStandardAssets.ImageEffects.BloomOptimized::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void BloomOptimized_OnRenderImage_mDDBA8F4CFCDFFCFF22538ABC9F53E155EEBF2A77 ();
// 0x00000017 System.Void UnityStandardAssets.ImageEffects.BloomOptimized::.ctor()
extern void BloomOptimized__ctor_m7D12176638B5C95A5B0ECEF237B979071183C59B ();
// 0x00000018 UnityEngine.Material UnityStandardAssets.ImageEffects.Blur::get_material()
extern void Blur_get_material_mA78CC6864A1F4CF4F6516E0BE4EC3D7352DCA6F6 ();
// 0x00000019 System.Void UnityStandardAssets.ImageEffects.Blur::OnDisable()
extern void Blur_OnDisable_m69A77A935D286E9E10A71B4C541FB336433EEF4A ();
// 0x0000001A System.Void UnityStandardAssets.ImageEffects.Blur::Start()
extern void Blur_Start_m671E5AA53CB3046B8E1487771D744379D76173BF ();
// 0x0000001B System.Void UnityStandardAssets.ImageEffects.Blur::FourTapCone(UnityEngine.RenderTexture,UnityEngine.RenderTexture,System.Int32)
extern void Blur_FourTapCone_m71056B588F10C15AD455683859B51D6637091CAC ();
// 0x0000001C System.Void UnityStandardAssets.ImageEffects.Blur::DownSample4x(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Blur_DownSample4x_mA4FCF00C3664CCD8BA7737EAA0B9DFC3AC33C59C ();
// 0x0000001D System.Void UnityStandardAssets.ImageEffects.Blur::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Blur_OnRenderImage_m5B3FAA032E4882D594AC0F01B15162807AD81AED ();
// 0x0000001E System.Void UnityStandardAssets.ImageEffects.Blur::.ctor()
extern void Blur__ctor_m2E2A4A2790C17E5FE8A3E6E7BC475026DB462686 ();
// 0x0000001F System.Void UnityStandardAssets.ImageEffects.Blur::.cctor()
extern void Blur__cctor_mA73F59B7D2C8520709C0BEF6FA9E117C7B8422CD ();
// 0x00000020 System.Boolean UnityStandardAssets.ImageEffects.BlurOptimized::CheckResources()
extern void BlurOptimized_CheckResources_m7C733652AD37CC67CA72018677EC5024A91EB92F ();
// 0x00000021 System.Void UnityStandardAssets.ImageEffects.BlurOptimized::OnDisable()
extern void BlurOptimized_OnDisable_mFB0A48F457243BAD0CD2978675F17B55AEB70463 ();
// 0x00000022 System.Void UnityStandardAssets.ImageEffects.BlurOptimized::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void BlurOptimized_OnRenderImage_m2DA65AD6DB764CC5A3DFFF6017077F3D9C868183 ();
// 0x00000023 System.Void UnityStandardAssets.ImageEffects.BlurOptimized::.ctor()
extern void BlurOptimized__ctor_mF2CAECAFB429E586A5C9307C29D55F1ABE996A80 ();
// 0x00000024 System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::CalculateViewProjection()
extern void CameraMotionBlur_CalculateViewProjection_m4113A637085024B08B80F3F69D1945FE738FC1C7 ();
// 0x00000025 System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::Start()
extern void CameraMotionBlur_Start_mFBF50D53B01E31653982FDC149B4C26EC5D265B6 ();
// 0x00000026 System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::OnEnable()
extern void CameraMotionBlur_OnEnable_mF3AD67713F3FE3172E16E3AF68CF337CE357D899 ();
// 0x00000027 System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::OnDisable()
extern void CameraMotionBlur_OnDisable_m5148C966633B3DA9C0C3026B1156C733533E982A ();
// 0x00000028 System.Boolean UnityStandardAssets.ImageEffects.CameraMotionBlur::CheckResources()
extern void CameraMotionBlur_CheckResources_m0986ED800445AE5B192905B47A2C8F1E96CFBFA9 ();
// 0x00000029 System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void CameraMotionBlur_OnRenderImage_m47EBA911A70FAAC719243096B66B750973E9B3D1 ();
// 0x0000002A System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::Remember()
extern void CameraMotionBlur_Remember_m279B766C194E8B9BB0792E609F55FB9804428F56 ();
// 0x0000002B UnityEngine.Camera UnityStandardAssets.ImageEffects.CameraMotionBlur::GetTmpCam()
extern void CameraMotionBlur_GetTmpCam_mD17DD474B53EE2E52E095148D0F081346669A961 ();
// 0x0000002C System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::StartFrame()
extern void CameraMotionBlur_StartFrame_m76A202342D32FC72D50FAC86D7EDE201BAF38786 ();
// 0x0000002D System.Int32 UnityStandardAssets.ImageEffects.CameraMotionBlur::divRoundUp(System.Int32,System.Int32)
extern void CameraMotionBlur_divRoundUp_mD914B62ABFC65F49BBB2AF3C9625ACA3B70898FF ();
// 0x0000002E System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::.ctor()
extern void CameraMotionBlur__ctor_mAC7F0EF8300A7BAEEEC0D28DD18F6EB28083ECBB ();
// 0x0000002F System.Void UnityStandardAssets.ImageEffects.CameraMotionBlur::.cctor()
extern void CameraMotionBlur__cctor_m937CF6073534212C4EF2CFEDCEAD126D109301BB ();
// 0x00000030 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionCurves::Start()
extern void ColorCorrectionCurves_Start_m8C11CAE0CB57C86CBCE9CB6150A3285A890E23FB ();
// 0x00000031 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionCurves::Awake()
extern void ColorCorrectionCurves_Awake_m9098F9B87364FC745D5E957D9AB2C2E0DD111BB3 ();
// 0x00000032 System.Boolean UnityStandardAssets.ImageEffects.ColorCorrectionCurves::CheckResources()
extern void ColorCorrectionCurves_CheckResources_m7B83F97C47F6140212ECB9A2C19A672E8EFC0BCA ();
// 0x00000033 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionCurves::UpdateParameters()
extern void ColorCorrectionCurves_UpdateParameters_m45A411338A64C382F344CEC47BA7511F41AABD13 ();
// 0x00000034 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionCurves::UpdateTextures()
extern void ColorCorrectionCurves_UpdateTextures_mC4FE3D3103875ABEBFFF09919EC65BD26DC5255D ();
// 0x00000035 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionCurves::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ColorCorrectionCurves_OnRenderImage_m69AA467A32BCED95118DDD711A82BDFBCFA56D7A ();
// 0x00000036 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionCurves::.ctor()
extern void ColorCorrectionCurves__ctor_m412D7B814A77ECA3A56682C1234E7F7FD1C0C9FB ();
// 0x00000037 System.Boolean UnityStandardAssets.ImageEffects.ColorCorrectionLookup::CheckResources()
extern void ColorCorrectionLookup_CheckResources_m936445D39C45BCC4500CF220AA5334310A06B94A ();
// 0x00000038 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionLookup::OnDisable()
extern void ColorCorrectionLookup_OnDisable_m02859D332B1470C68820895502D795F9FE374C3A ();
// 0x00000039 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionLookup::OnDestroy()
extern void ColorCorrectionLookup_OnDestroy_mA9C80B55F38F8E5BEDFFF807C689F6B3A8D15B73 ();
// 0x0000003A System.Void UnityStandardAssets.ImageEffects.ColorCorrectionLookup::SetIdentityLut()
extern void ColorCorrectionLookup_SetIdentityLut_mB972F312081581EA2A8EDE79DC3D98683C26612D ();
// 0x0000003B System.Boolean UnityStandardAssets.ImageEffects.ColorCorrectionLookup::ValidDimensions(UnityEngine.Texture2D)
extern void ColorCorrectionLookup_ValidDimensions_mCE4FC5CE5F0C7C606DFC73A441443C58D8D68F9A ();
// 0x0000003C System.Void UnityStandardAssets.ImageEffects.ColorCorrectionLookup::Convert(UnityEngine.Texture2D,System.String)
extern void ColorCorrectionLookup_Convert_m6C389BDA8FAE5B0ED75C22416CB94780AC1036CC ();
// 0x0000003D System.Void UnityStandardAssets.ImageEffects.ColorCorrectionLookup::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ColorCorrectionLookup_OnRenderImage_mD0352CEF7EB4F4FF6A0928A950C2A1FE1455572A ();
// 0x0000003E System.Void UnityStandardAssets.ImageEffects.ColorCorrectionLookup::.ctor()
extern void ColorCorrectionLookup__ctor_mDCF2798253BECF30B5DC894780A83404A542DA8C ();
// 0x0000003F System.Void UnityStandardAssets.ImageEffects.ColorCorrectionRamp::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ColorCorrectionRamp_OnRenderImage_m8BEEBE37D7500310CDF3C081E736ABD03D8D3184 ();
// 0x00000040 System.Void UnityStandardAssets.ImageEffects.ColorCorrectionRamp::.ctor()
extern void ColorCorrectionRamp__ctor_mF21655C19334A48C1E5C7FD256C0173EE74B67A2 ();
// 0x00000041 System.Boolean UnityStandardAssets.ImageEffects.ContrastEnhance::CheckResources()
extern void ContrastEnhance_CheckResources_m4C273D28A003ED045F1A9DF7ABCCCC02CE2C42B3 ();
// 0x00000042 System.Void UnityStandardAssets.ImageEffects.ContrastEnhance::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ContrastEnhance_OnRenderImage_m16B76BCF6DB8FE2DFB6692B2138373A7DB7AE0B7 ();
// 0x00000043 System.Void UnityStandardAssets.ImageEffects.ContrastEnhance::.ctor()
extern void ContrastEnhance__ctor_m5494D801101246FF95584EA6745D899389FF06DD ();
// 0x00000044 UnityEngine.Material UnityStandardAssets.ImageEffects.ContrastStretch::get_materialLum()
extern void ContrastStretch_get_materialLum_m0D02A7A771E1A767717161959DA76D930B586A73 ();
// 0x00000045 UnityEngine.Material UnityStandardAssets.ImageEffects.ContrastStretch::get_materialReduce()
extern void ContrastStretch_get_materialReduce_mC351F3F30FC1EFF05E02710BE601B20B45D4721A ();
// 0x00000046 UnityEngine.Material UnityStandardAssets.ImageEffects.ContrastStretch::get_materialAdapt()
extern void ContrastStretch_get_materialAdapt_mBCC58882ACA33BE2D972EF3023C585FF43CA9ED6 ();
// 0x00000047 UnityEngine.Material UnityStandardAssets.ImageEffects.ContrastStretch::get_materialApply()
extern void ContrastStretch_get_materialApply_m83520035795F75431A4FA67718EB364A08C6869F ();
// 0x00000048 System.Void UnityStandardAssets.ImageEffects.ContrastStretch::Start()
extern void ContrastStretch_Start_m37FD7E59064319B99C181B5E441956D9DD805BA9 ();
// 0x00000049 System.Void UnityStandardAssets.ImageEffects.ContrastStretch::OnEnable()
extern void ContrastStretch_OnEnable_mAED566583E7BFDB6D5D675054C93966529444BFA ();
// 0x0000004A System.Void UnityStandardAssets.ImageEffects.ContrastStretch::OnDisable()
extern void ContrastStretch_OnDisable_mCB3F858ACC8144C26B8502167A6C60508742B329 ();
// 0x0000004B System.Void UnityStandardAssets.ImageEffects.ContrastStretch::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ContrastStretch_OnRenderImage_mD15C826C83ABB903A0FA3191C5D58901FD32EDDA ();
// 0x0000004C System.Void UnityStandardAssets.ImageEffects.ContrastStretch::CalculateAdaptation(UnityEngine.Texture)
extern void ContrastStretch_CalculateAdaptation_m1FEEEA7976F0A0E1F5B7E03CC6D6B20B3B8F4403 ();
// 0x0000004D System.Void UnityStandardAssets.ImageEffects.ContrastStretch::.ctor()
extern void ContrastStretch__ctor_mDF0B21BF845EE65245A49F6A40858EDC0325BB7A ();
// 0x0000004E System.Boolean UnityStandardAssets.ImageEffects.CreaseShading::CheckResources()
extern void CreaseShading_CheckResources_mA39D76AD7F4137295B62A3A1E82EBCD0F8014F2F ();
// 0x0000004F System.Void UnityStandardAssets.ImageEffects.CreaseShading::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void CreaseShading_OnRenderImage_mD67F9FBBE12E54F70230DF539DEA74BA0E5BF4E9 ();
// 0x00000050 System.Void UnityStandardAssets.ImageEffects.CreaseShading::.ctor()
extern void CreaseShading__ctor_mF59E60629F82D223EC50BEC164ED8BCC801BEE4D ();
// 0x00000051 System.Boolean UnityStandardAssets.ImageEffects.DepthOfField::CheckResources()
extern void DepthOfField_CheckResources_mFF4623AE1526947893CE07434D56D297CDBA58F8 ();
// 0x00000052 System.Void UnityStandardAssets.ImageEffects.DepthOfField::OnEnable()
extern void DepthOfField_OnEnable_mD0B0891326524D1173E68F86847C218E6E7DD921 ();
// 0x00000053 System.Void UnityStandardAssets.ImageEffects.DepthOfField::OnDisable()
extern void DepthOfField_OnDisable_mAE76CEB0CDB7A59FB4D153373F293ABEA56E524E ();
// 0x00000054 System.Void UnityStandardAssets.ImageEffects.DepthOfField::ReleaseComputeResources()
extern void DepthOfField_ReleaseComputeResources_mE1DFEC71DEAACA30A278D8C7554C0316784157A5 ();
// 0x00000055 System.Void UnityStandardAssets.ImageEffects.DepthOfField::CreateComputeResources()
extern void DepthOfField_CreateComputeResources_m0ADD9C7AA1AA59F482ADB659F3846A915B50B447 ();
// 0x00000056 System.Single UnityStandardAssets.ImageEffects.DepthOfField::FocalDistance01(System.Single)
extern void DepthOfField_FocalDistance01_mB097CA88DA3A6EFF2BCA0ADBE82CFA9609227546 ();
// 0x00000057 System.Void UnityStandardAssets.ImageEffects.DepthOfField::WriteCoc(UnityEngine.RenderTexture,System.Boolean)
extern void DepthOfField_WriteCoc_mA9CFBC6A691FE3AD1C51A9381BA3A77B80A0E913 ();
// 0x00000058 System.Void UnityStandardAssets.ImageEffects.DepthOfField::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void DepthOfField_OnRenderImage_m8806DA4A44BCF3CFA9441A8EC39107D1A5B3B72F ();
// 0x00000059 System.Void UnityStandardAssets.ImageEffects.DepthOfField::.ctor()
extern void DepthOfField__ctor_m2DDFF0431458E06C8C53DD5A797EA6571C02B0E8 ();
// 0x0000005A System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::CreateMaterials()
extern void DepthOfFieldDeprecated_CreateMaterials_m7E864DCC1D3DF384FCC7AE3A394FB61753FC935F ();
// 0x0000005B System.Boolean UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::CheckResources()
extern void DepthOfFieldDeprecated_CheckResources_m57F9DB671AFDAD84ABAFC2412B116AFCED59D545 ();
// 0x0000005C System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::OnDisable()
extern void DepthOfFieldDeprecated_OnDisable_mDDB999F017D483B0CFAABEBE17148A1739EEAEA4 ();
// 0x0000005D System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::OnEnable()
extern void DepthOfFieldDeprecated_OnEnable_m823BFC708B75CC6E04576D3AD6894A8CF9ED9DF2 ();
// 0x0000005E System.Single UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::FocalDistance01(System.Single)
extern void DepthOfFieldDeprecated_FocalDistance01_mF372E4CACD8CD9CEF57325523577F2728D850809 ();
// 0x0000005F System.Int32 UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::GetDividerBasedOnQuality()
extern void DepthOfFieldDeprecated_GetDividerBasedOnQuality_m4C92DBAE3BF80F98FF128078185BC3675D1EB121 ();
// 0x00000060 System.Int32 UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::GetLowResolutionDividerBasedOnQuality(System.Int32)
extern void DepthOfFieldDeprecated_GetLowResolutionDividerBasedOnQuality_m21AEB48E74DDD5332A180B798BB0BC1895F5680D ();
// 0x00000061 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void DepthOfFieldDeprecated_OnRenderImage_m4FD02819120EF0763ABCDA0F26E3F9C082E96595 ();
// 0x00000062 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::Blur(UnityEngine.RenderTexture,UnityEngine.RenderTexture,UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated_DofBlurriness,System.Int32,System.Single)
extern void DepthOfFieldDeprecated_Blur_m38AF1CF44891304E473D29FA27EAB2C50195522C ();
// 0x00000063 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::BlurFg(UnityEngine.RenderTexture,UnityEngine.RenderTexture,UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated_DofBlurriness,System.Int32,System.Single)
extern void DepthOfFieldDeprecated_BlurFg_m831640C176288E0845AB4AB4C0729BF9DA326D7F ();
// 0x00000064 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::BlurHex(UnityEngine.RenderTexture,UnityEngine.RenderTexture,System.Int32,System.Single,UnityEngine.RenderTexture)
extern void DepthOfFieldDeprecated_BlurHex_m1DA49B64915A6BFFC8669BF4C811801A05F921D2 ();
// 0x00000065 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::Downsample(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void DepthOfFieldDeprecated_Downsample_m5B5A94F17F06EEC638B8A3B2CB0BF2E8C01761C7 ();
// 0x00000066 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::AddBokeh(UnityEngine.RenderTexture,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void DepthOfFieldDeprecated_AddBokeh_mD44A5A7C08642E7FE9DAE6EBE3959841E47700CD ();
// 0x00000067 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::ReleaseTextures()
extern void DepthOfFieldDeprecated_ReleaseTextures_mBF3F404B9476878E1EECBEF4F11E43D5C435370A ();
// 0x00000068 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::AllocateTextures(System.Boolean,UnityEngine.RenderTexture,System.Int32,System.Int32)
extern void DepthOfFieldDeprecated_AllocateTextures_mEEE3303442CEE81510D4AFC573D343199A9CCF38 ();
// 0x00000069 System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::.ctor()
extern void DepthOfFieldDeprecated__ctor_m470B5306F1CEF2BBCA46150B4BDC39523B39E7A8 ();
// 0x0000006A System.Void UnityStandardAssets.ImageEffects.DepthOfFieldDeprecated::.cctor()
extern void DepthOfFieldDeprecated__cctor_m3FF5D0274DAEA3E0FED59E3315B607FA8CA2F325 ();
// 0x0000006B System.Boolean UnityStandardAssets.ImageEffects.EdgeDetection::CheckResources()
extern void EdgeDetection_CheckResources_m77968AAE4F770D8519478DD7ECBE4DD7AED1CEFE ();
// 0x0000006C System.Void UnityStandardAssets.ImageEffects.EdgeDetection::Start()
extern void EdgeDetection_Start_m806A4D2E0B9BF8E9C2E6E185642D4FBC56DDC90C ();
// 0x0000006D System.Void UnityStandardAssets.ImageEffects.EdgeDetection::SetCameraFlag()
extern void EdgeDetection_SetCameraFlag_mB0E693AE23207D73F1FD8CF254A189189D181FB7 ();
// 0x0000006E System.Void UnityStandardAssets.ImageEffects.EdgeDetection::OnEnable()
extern void EdgeDetection_OnEnable_m6981429E39B47DC1BC6EA398D3540D1C7852D1ED ();
// 0x0000006F System.Void UnityStandardAssets.ImageEffects.EdgeDetection::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void EdgeDetection_OnRenderImage_mE34D4EFE02009C8585D83B8196ACF2EF40A44E85 ();
// 0x00000070 System.Void UnityStandardAssets.ImageEffects.EdgeDetection::.ctor()
extern void EdgeDetection__ctor_m6819FFBE592107ABA108BC44CC77DC1BF7869893 ();
// 0x00000071 System.Boolean UnityStandardAssets.ImageEffects.Fisheye::CheckResources()
extern void Fisheye_CheckResources_mA77AB76AFD5BCBABAF4544307A7266225A46981B ();
// 0x00000072 System.Void UnityStandardAssets.ImageEffects.Fisheye::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Fisheye_OnRenderImage_m2E866F1F44A61714EF8B3EC6CFEF98E4B9078A6C ();
// 0x00000073 System.Void UnityStandardAssets.ImageEffects.Fisheye::.ctor()
extern void Fisheye__ctor_m0F4AD162A2EA39B007B1F84756B4A9C646285DA5 ();
// 0x00000074 System.Boolean UnityStandardAssets.ImageEffects.GlobalFog::CheckResources()
extern void GlobalFog_CheckResources_mEC1BF4E75C7F7083123AE74494FC72E258787F0C ();
// 0x00000075 System.Void UnityStandardAssets.ImageEffects.GlobalFog::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void GlobalFog_OnRenderImage_m974B8C5F27B91FCA36B82808377068B6A38A3806 ();
// 0x00000076 System.Void UnityStandardAssets.ImageEffects.GlobalFog::.ctor()
extern void GlobalFog__ctor_m884187835D88AE1E1E0FCD1DC8D8389382ABCFED ();
// 0x00000077 System.Void UnityStandardAssets.ImageEffects.Grayscale::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Grayscale_OnRenderImage_mC77D55DCB26C79586251A141ECCEB22A6F0C7C55 ();
// 0x00000078 System.Void UnityStandardAssets.ImageEffects.Grayscale::.ctor()
extern void Grayscale__ctor_m8FC49D53FB6BA407C8F723A43D7DE9DF478652F0 ();
// 0x00000079 System.Void UnityStandardAssets.ImageEffects.ImageEffectBase::Start()
extern void ImageEffectBase_Start_m0B8BE75EEF30FB0859184CC585613DC0C8F78914 ();
// 0x0000007A UnityEngine.Material UnityStandardAssets.ImageEffects.ImageEffectBase::get_material()
extern void ImageEffectBase_get_material_mA8C588D469CA3BD4912E1134859B2CF27AC910BF ();
// 0x0000007B System.Void UnityStandardAssets.ImageEffects.ImageEffectBase::OnDisable()
extern void ImageEffectBase_OnDisable_mD7017DFB0EA0C265AEBDE9AF4F83334AA9F4753D ();
// 0x0000007C System.Void UnityStandardAssets.ImageEffects.ImageEffectBase::.ctor()
extern void ImageEffectBase__ctor_mB771C56D15574F48908C288F4C219590311272FF ();
// 0x0000007D System.Void UnityStandardAssets.ImageEffects.ImageEffects::RenderDistortion(UnityEngine.Material,UnityEngine.RenderTexture,UnityEngine.RenderTexture,System.Single,UnityEngine.Vector2,UnityEngine.Vector2)
extern void ImageEffects_RenderDistortion_m502BE4AA0D08445AF1037185CCBB47551B103D76 ();
// 0x0000007E System.Void UnityStandardAssets.ImageEffects.ImageEffects::Blit(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ImageEffects_Blit_m6DD0BB12C95116A09D62B3C186FC25D6DFFF6966 ();
// 0x0000007F System.Void UnityStandardAssets.ImageEffects.ImageEffects::BlitWithMaterial(UnityEngine.Material,UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ImageEffects_BlitWithMaterial_m3C75FB03C841A99760A70344A67B76327E791676 ();
// 0x00000080 System.Void UnityStandardAssets.ImageEffects.ImageEffects::.ctor()
extern void ImageEffects__ctor_mBEF21EA29F71955781BC8DCE6B5F6025C58BB28D ();
// 0x00000081 System.Void UnityStandardAssets.ImageEffects.MotionBlur::Start()
extern void MotionBlur_Start_mE69D3D0ABF43F66A54054C7891F26089D17AFEE4 ();
// 0x00000082 System.Void UnityStandardAssets.ImageEffects.MotionBlur::OnDisable()
extern void MotionBlur_OnDisable_mFFEFB4A703090B8ECBAC9753F8E3B041032AF9E3 ();
// 0x00000083 System.Void UnityStandardAssets.ImageEffects.MotionBlur::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void MotionBlur_OnRenderImage_m5BCB2A20A5C35EE5CB974A6B5D1115C120053EB8 ();
// 0x00000084 System.Void UnityStandardAssets.ImageEffects.MotionBlur::.ctor()
extern void MotionBlur__ctor_m103E002CBF7AD5898088A5E79A5007C2A770A413 ();
// 0x00000085 System.Boolean UnityStandardAssets.ImageEffects.NoiseAndGrain::CheckResources()
extern void NoiseAndGrain_CheckResources_mC8D77D1483367A20E613E5CBBBB00F39D5AD1FB8 ();
// 0x00000086 System.Void UnityStandardAssets.ImageEffects.NoiseAndGrain::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void NoiseAndGrain_OnRenderImage_m5D12B699F5844F55A4004651E1230C1B066A3C18 ();
// 0x00000087 System.Void UnityStandardAssets.ImageEffects.NoiseAndGrain::DrawNoiseQuadGrid(UnityEngine.RenderTexture,UnityEngine.RenderTexture,UnityEngine.Material,UnityEngine.Texture2D,System.Int32)
extern void NoiseAndGrain_DrawNoiseQuadGrid_m559228D062603ADF90CA4F710648953C3D4CA363 ();
// 0x00000088 System.Void UnityStandardAssets.ImageEffects.NoiseAndGrain::.ctor()
extern void NoiseAndGrain__ctor_mDE68721108A8C7CC3BE0A8DDB1A14D04F586917D ();
// 0x00000089 System.Void UnityStandardAssets.ImageEffects.NoiseAndGrain::.cctor()
extern void NoiseAndGrain__cctor_m75F028DC54C6ADA78CDE97F62B1D7A0A152ED11D ();
// 0x0000008A System.Void UnityStandardAssets.ImageEffects.NoiseAndScratches::Start()
extern void NoiseAndScratches_Start_mB15AADF01E6D83CA015C97C28AEDE6568BCC7424 ();
// 0x0000008B UnityEngine.Material UnityStandardAssets.ImageEffects.NoiseAndScratches::get_material()
extern void NoiseAndScratches_get_material_m1606C8BB8FD10FB2C9AC839ACED40BFB6D354193 ();
// 0x0000008C System.Void UnityStandardAssets.ImageEffects.NoiseAndScratches::OnDisable()
extern void NoiseAndScratches_OnDisable_mB1BE49CB7E5B744ED0AD4032BE0D4A60ACDF7EC8 ();
// 0x0000008D System.Void UnityStandardAssets.ImageEffects.NoiseAndScratches::SanitizeParameters()
extern void NoiseAndScratches_SanitizeParameters_m21DE2EAA33D1875E6D27D7588F2392C99B947697 ();
// 0x0000008E System.Void UnityStandardAssets.ImageEffects.NoiseAndScratches::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void NoiseAndScratches_OnRenderImage_m570F49BF4167D67480E3F371F863D46416DDA6B8 ();
// 0x0000008F System.Void UnityStandardAssets.ImageEffects.NoiseAndScratches::.ctor()
extern void NoiseAndScratches__ctor_m836D75D0546111B1F1F77EB14D4475E1AC489224 ();
// 0x00000090 UnityEngine.Material UnityStandardAssets.ImageEffects.PostEffectsBase::CheckShaderAndCreateMaterial(UnityEngine.Shader,UnityEngine.Material)
extern void PostEffectsBase_CheckShaderAndCreateMaterial_m7EA37EFD394AA82B4D24059D78E9337EAE917A1B ();
// 0x00000091 UnityEngine.Material UnityStandardAssets.ImageEffects.PostEffectsBase::CreateMaterial(UnityEngine.Shader,UnityEngine.Material)
extern void PostEffectsBase_CreateMaterial_m7256FCF60E5E7377200668EE705C6FA01B4ED026 ();
// 0x00000092 System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::OnEnable()
extern void PostEffectsBase_OnEnable_m21BECBF1006EF102FE6AF8EC9FA9468052723ECE ();
// 0x00000093 System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::OnDestroy()
extern void PostEffectsBase_OnDestroy_mCFF1154859A309F1F5A7C6F1F83A11F30EF4E607 ();
// 0x00000094 System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::RemoveCreatedMaterials()
extern void PostEffectsBase_RemoveCreatedMaterials_m1E4EE64C79DCDD6E2952A69E43AF2A1F7DB2443C ();
// 0x00000095 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckSupport()
extern void PostEffectsBase_CheckSupport_m46DF5BC2831150955600DD98F32069B7A750D032 ();
// 0x00000096 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckResources()
extern void PostEffectsBase_CheckResources_mD1FD25B17E3A3266BF8BF3C4DB54C2322C0450D5 ();
// 0x00000097 System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::Start()
extern void PostEffectsBase_Start_m722B325C26402B2C8E1B08419656161373EAE341 ();
// 0x00000098 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckSupport(System.Boolean)
extern void PostEffectsBase_CheckSupport_mADFD99E7F258D0BB95385FD0D8AFCE7A941AF44A ();
// 0x00000099 System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckSupport(System.Boolean,System.Boolean)
extern void PostEffectsBase_CheckSupport_m5F9E1F82A5FD22657529FAEE8FEC6B800B86BB64 ();
// 0x0000009A System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::Dx11Support()
extern void PostEffectsBase_Dx11Support_mF74FA1E653FC2BF47BC252B602411EBBCB5264C5 ();
// 0x0000009B System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::ReportAutoDisable()
extern void PostEffectsBase_ReportAutoDisable_m4EBCB675A21C994DE7AAFEDC02587F07A0162917 ();
// 0x0000009C System.Boolean UnityStandardAssets.ImageEffects.PostEffectsBase::CheckShader(UnityEngine.Shader)
extern void PostEffectsBase_CheckShader_mFC9D581D608597D8FDC0D1C6DC11509243D25412 ();
// 0x0000009D System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::NotSupported()
extern void PostEffectsBase_NotSupported_mB602B43321D89C83568F500F8BD76D0B303D8507 ();
// 0x0000009E System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::DrawBorder(UnityEngine.RenderTexture,UnityEngine.Material)
extern void PostEffectsBase_DrawBorder_m79DE79BA785A598EB819C0FC1B9E7EB929E46EBF ();
// 0x0000009F System.Void UnityStandardAssets.ImageEffects.PostEffectsBase::.ctor()
extern void PostEffectsBase__ctor_m78DEC2AC3926DBAE98BDCCC2FD8346DD52E3D7D8 ();
// 0x000000A0 System.Void UnityStandardAssets.ImageEffects.PostEffectsHelper::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void PostEffectsHelper_OnRenderImage_m479B964ADE9ABF36AC6203D7594884F508E9FF47 ();
// 0x000000A1 System.Void UnityStandardAssets.ImageEffects.PostEffectsHelper::DrawLowLevelPlaneAlignedWithCamera(System.Single,UnityEngine.RenderTexture,UnityEngine.RenderTexture,UnityEngine.Material,UnityEngine.Camera)
extern void PostEffectsHelper_DrawLowLevelPlaneAlignedWithCamera_m92F1ADC8B006801B8CB9E0C966D165D78D51E91B ();
// 0x000000A2 System.Void UnityStandardAssets.ImageEffects.PostEffectsHelper::DrawBorder(UnityEngine.RenderTexture,UnityEngine.Material)
extern void PostEffectsHelper_DrawBorder_m32A1BA6A7D2A1B7D9B5CB9A87739C35593ECE4CF ();
// 0x000000A3 System.Void UnityStandardAssets.ImageEffects.PostEffectsHelper::DrawLowLevelQuad(System.Single,System.Single,System.Single,System.Single,UnityEngine.RenderTexture,UnityEngine.RenderTexture,UnityEngine.Material)
extern void PostEffectsHelper_DrawLowLevelQuad_mBA588FFD508359BB81EAB9DF149B4A3A91E177E5 ();
// 0x000000A4 System.Void UnityStandardAssets.ImageEffects.PostEffectsHelper::.ctor()
extern void PostEffectsHelper__ctor_m3BA590F71D3CDC362DA541CB562456B7E0AEB1D7 ();
// 0x000000A5 System.Boolean UnityStandardAssets.ImageEffects.Quads::HasMeshes()
extern void Quads_HasMeshes_mCDA1AF7E4D2C0448EB0031D73FC31B3A013D95A9 ();
// 0x000000A6 System.Void UnityStandardAssets.ImageEffects.Quads::Cleanup()
extern void Quads_Cleanup_mC27BEBC330A8E2D9BC2C880A020A28AD5787C919 ();
// 0x000000A7 UnityEngine.Mesh[] UnityStandardAssets.ImageEffects.Quads::GetMeshes(System.Int32,System.Int32)
extern void Quads_GetMeshes_mCAD4B92A5E9216F4AE2CD7AC053E57A9040BE71C ();
// 0x000000A8 UnityEngine.Mesh UnityStandardAssets.ImageEffects.Quads::GetMesh(System.Int32,System.Int32,System.Int32,System.Int32)
extern void Quads_GetMesh_m4E7E21533CEB935492A6FBA2C40DA832935B8C66 ();
// 0x000000A9 System.Void UnityStandardAssets.ImageEffects.Quads::.ctor()
extern void Quads__ctor_m178BAB45871CF3B27D02AF03F0394C618D03EC1A ();
// 0x000000AA System.Void UnityStandardAssets.ImageEffects.Quads::.cctor()
extern void Quads__cctor_m8DF4521108A46E4BC6F4097912E197037A4D5C5C ();
// 0x000000AB System.Boolean UnityStandardAssets.ImageEffects.ScreenOverlay::CheckResources()
extern void ScreenOverlay_CheckResources_m9652014AC8645005FD46677B491ADB2E49B7C0BF ();
// 0x000000AC System.Void UnityStandardAssets.ImageEffects.ScreenOverlay::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ScreenOverlay_OnRenderImage_m04BA614F8BD5B421DEDEF18BB6C7B2F3C7858DAC ();
// 0x000000AD System.Void UnityStandardAssets.ImageEffects.ScreenOverlay::.ctor()
extern void ScreenOverlay__ctor_m0D520F2A7539ECA884A34D0351267D8009EB24A7 ();
// 0x000000AE System.Boolean UnityStandardAssets.ImageEffects.ScreenSpaceAmbientObscurance::CheckResources()
extern void ScreenSpaceAmbientObscurance_CheckResources_m94E6CE933DB0741CDA966B3BD74D87C9C34EB32F ();
// 0x000000AF System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientObscurance::OnDisable()
extern void ScreenSpaceAmbientObscurance_OnDisable_mF178257C007A4449251E9A800B768040CA6B1901 ();
// 0x000000B0 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientObscurance::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ScreenSpaceAmbientObscurance_OnRenderImage_mAF0FB2C0263ACE051C464F761099E67BA8A50160 ();
// 0x000000B1 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientObscurance::.ctor()
extern void ScreenSpaceAmbientObscurance__ctor_mB6F187F68D922A42D317BA27A4236BEA1A83A29B ();
// 0x000000B2 UnityEngine.Material UnityStandardAssets.ImageEffects.ScreenSpaceAmbientOcclusion::CreateMaterial(UnityEngine.Shader)
extern void ScreenSpaceAmbientOcclusion_CreateMaterial_m91C949BB7E24B74C7DC4B33DE87626425D6CD0E6 ();
// 0x000000B3 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientOcclusion::DestroyMaterial(UnityEngine.Material)
extern void ScreenSpaceAmbientOcclusion_DestroyMaterial_m520AD4DE19AF81BBD992A242F14AF739B8039823 ();
// 0x000000B4 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientOcclusion::OnDisable()
extern void ScreenSpaceAmbientOcclusion_OnDisable_m571DFD1142ECBEF64B097480492F1E69A562A716 ();
// 0x000000B5 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientOcclusion::Start()
extern void ScreenSpaceAmbientOcclusion_Start_m20BD4CFC102696D49C7241A3BDFCB734AD988B5B ();
// 0x000000B6 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientOcclusion::OnEnable()
extern void ScreenSpaceAmbientOcclusion_OnEnable_m728A790197D8E897DCD5105052D8D1EC7D78E446 ();
// 0x000000B7 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientOcclusion::CreateMaterials()
extern void ScreenSpaceAmbientOcclusion_CreateMaterials_m21EA33E1E08232AF9B43CEF20D1DB6ABCCADDEFC ();
// 0x000000B8 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientOcclusion::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void ScreenSpaceAmbientOcclusion_OnRenderImage_m5212349218E44C8E6D18A25F1AC258961CDAE7A3 ();
// 0x000000B9 System.Void UnityStandardAssets.ImageEffects.ScreenSpaceAmbientOcclusion::.ctor()
extern void ScreenSpaceAmbientOcclusion__ctor_mC95EBF095908EFFA435BAA4B928DC0049CBCE6BF ();
// 0x000000BA System.Void UnityStandardAssets.ImageEffects.SepiaTone::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void SepiaTone_OnRenderImage_mF3B073827862274C0B9B6CEE2C95B39F603FCAB3 ();
// 0x000000BB System.Void UnityStandardAssets.ImageEffects.SepiaTone::.ctor()
extern void SepiaTone__ctor_m8DC1DFC72CEEF9AD0EBD6EF708C32446A945B24C ();
// 0x000000BC System.Boolean UnityStandardAssets.ImageEffects.SunShafts::CheckResources()
extern void SunShafts_CheckResources_m9CFFB8852D2BEF33CAE3405634F51E95E98994DA ();
// 0x000000BD System.Void UnityStandardAssets.ImageEffects.SunShafts::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void SunShafts_OnRenderImage_m0B78F16F7D0104E80D0B7155CFA1650AA342897F ();
// 0x000000BE System.Void UnityStandardAssets.ImageEffects.SunShafts::.ctor()
extern void SunShafts__ctor_m5A50800230C92569BD30CEBC2AE2F41375180A29 ();
// 0x000000BF System.Boolean UnityStandardAssets.ImageEffects.TiltShift::CheckResources()
extern void TiltShift_CheckResources_mD97D41BB18DBF86E79EB9987D66888EE7FBC8ECD ();
// 0x000000C0 System.Void UnityStandardAssets.ImageEffects.TiltShift::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void TiltShift_OnRenderImage_mC10C49389FF486CAD60C8FE8C3CC3F475DD1B1EA ();
// 0x000000C1 System.Void UnityStandardAssets.ImageEffects.TiltShift::.ctor()
extern void TiltShift__ctor_mB4B5B5D405033F79FEE41B5018C3AAF5074BC1B0 ();
// 0x000000C2 System.Boolean UnityStandardAssets.ImageEffects.Tonemapping::CheckResources()
extern void Tonemapping_CheckResources_m317B2A029F297AB72AB94B2D5D4E4D2EC5589D7C ();
// 0x000000C3 System.Single UnityStandardAssets.ImageEffects.Tonemapping::UpdateCurve()
extern void Tonemapping_UpdateCurve_mD366B0A2F2A1C946C41B989FA6D0DF11E4202D22 ();
// 0x000000C4 System.Void UnityStandardAssets.ImageEffects.Tonemapping::OnDisable()
extern void Tonemapping_OnDisable_m6C1516A147F54C28ECE029814E28440CBA74B5A4 ();
// 0x000000C5 System.Boolean UnityStandardAssets.ImageEffects.Tonemapping::CreateInternalRenderTexture()
extern void Tonemapping_CreateInternalRenderTexture_m9A69666FCE1399CAD7EDAEA4BA2997597D347183 ();
// 0x000000C6 System.Void UnityStandardAssets.ImageEffects.Tonemapping::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Tonemapping_OnRenderImage_m5C3295A239E9113D9A95EE75B6B4D55562DC1A9C ();
// 0x000000C7 System.Void UnityStandardAssets.ImageEffects.Tonemapping::.ctor()
extern void Tonemapping__ctor_mE5C67505418D47B6C17FEC1E7B99B0BB8DD5627D ();
// 0x000000C8 System.Boolean UnityStandardAssets.ImageEffects.Triangles::HasMeshes()
extern void Triangles_HasMeshes_mBD1CC9B21E38800033B5B84AB8CD708CCA75EE37 ();
// 0x000000C9 System.Void UnityStandardAssets.ImageEffects.Triangles::Cleanup()
extern void Triangles_Cleanup_mEE21C0D422FBBA3EFF7C0863901D831A00F1757C ();
// 0x000000CA UnityEngine.Mesh[] UnityStandardAssets.ImageEffects.Triangles::GetMeshes(System.Int32,System.Int32)
extern void Triangles_GetMeshes_mD5DF8B4F5248C1FEFD695733DD113A18AECDEDDC ();
// 0x000000CB UnityEngine.Mesh UnityStandardAssets.ImageEffects.Triangles::GetMesh(System.Int32,System.Int32,System.Int32,System.Int32)
extern void Triangles_GetMesh_mF19BD126BA8636F5861FBC67CEC2CBEA8DEED962 ();
// 0x000000CC System.Void UnityStandardAssets.ImageEffects.Triangles::.ctor()
extern void Triangles__ctor_mEDE5B5520FDB64307AE34DD49DA8B3FB49267A96 ();
// 0x000000CD System.Void UnityStandardAssets.ImageEffects.Triangles::.cctor()
extern void Triangles__cctor_m4CF7CC014DE88B02B2906FB4C947D8DC17D2A4A6 ();
// 0x000000CE System.Void UnityStandardAssets.ImageEffects.Twirl::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Twirl_OnRenderImage_mDC62A58F6242107DF15D252D86AF74E2E4A34980 ();
// 0x000000CF System.Void UnityStandardAssets.ImageEffects.Twirl::.ctor()
extern void Twirl__ctor_m5E24773FB247B2D4F3377960734EA184026E5A2D ();
// 0x000000D0 System.Boolean UnityStandardAssets.ImageEffects.VignetteAndChromaticAberration::CheckResources()
extern void VignetteAndChromaticAberration_CheckResources_mAEB75CE9EEE61DD2662CA5C320701A0EE60B63C1 ();
// 0x000000D1 System.Void UnityStandardAssets.ImageEffects.VignetteAndChromaticAberration::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void VignetteAndChromaticAberration_OnRenderImage_mE0CE6D9AA45DA1650026CD87C01D4956C63573A7 ();
// 0x000000D2 System.Void UnityStandardAssets.ImageEffects.VignetteAndChromaticAberration::.ctor()
extern void VignetteAndChromaticAberration__ctor_m2FD6F170E6CE7256F57A57EA2F6686E937B2A075 ();
// 0x000000D3 System.Void UnityStandardAssets.ImageEffects.Vortex::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Vortex_OnRenderImage_mCFBFC02516C719C8D6E8F738EDB2DC1A0E7F8D49 ();
// 0x000000D4 System.Void UnityStandardAssets.ImageEffects.Vortex::.ctor()
extern void Vortex__ctor_m4320E4081F0959DDD299C17445D77D67109D0084 ();
static Il2CppMethodPointer s_methodPointers[212] = 
{
	Antialiasing_CurrentAAMaterial_m35A9DADF746986D8155C7B16699CC757DD9645EA,
	Antialiasing_CheckResources_m992294E535DD40C212A746ACAC3B4B890C6A5187,
	Antialiasing_OnRenderImage_mDAEAD8526443B85398951FB1AB482759C3D3230F,
	Antialiasing__ctor_mEF11CF01265269B2A640833625EDA610C80E104D,
	Bloom_CheckResources_mC9CAC511BFD2007A470C8DCCB4048466EFBAF2CD,
	Bloom_OnRenderImage_m92C9B1E77D73E8761AA9B976AF05DAA17F30A447,
	Bloom_AddTo_m35AF7DA3D13378B52D4AD626637F5A34C0FAAA51,
	Bloom_BlendFlares_mF1A0DB8193EE254FC79CEF319993A87E441A219C,
	Bloom_BrightFilter_m057C5D3B47D7AFB9B1ACAC512A465309E66CEB21,
	Bloom_BrightFilter_mE98F787A51FA04D86D06850FF587CED2DD5DCF4E,
	Bloom_Vignette_mB955F94B50143F8FF36BCE05CEFF197BA6D3453B,
	Bloom__ctor_m671E3ABA13568745A5C1FA0A9528387C6C13F310,
	BloomAndFlares_CheckResources_m4DCB928EB6919CB75CB6279E5C56D4921805A68F,
	BloomAndFlares_OnRenderImage_m863EF5506BE3DA81DAA863FD799DA2FFD287F836,
	BloomAndFlares_AddTo_mD2B5CCC7CE591EF7788737C3B51601E7EAAA364D,
	BloomAndFlares_BlendFlares_m10B4C8B7ED21842C3B3FE0B2E8490516B4794EF8,
	BloomAndFlares_BrightFilter_m3191A51782383B22BED4FB7DECF96F84FEFA41AA,
	BloomAndFlares_Vignette_m3ECA2114A2D5AB08DFA0EB013794639808A550A3,
	BloomAndFlares__ctor_mFBE9184D02B3D517C3FEB725127BE4775B8CB3FB,
	BloomOptimized_CheckResources_mBE0B61C792C2E55D2D83A4D8E784F2810D3F02AA,
	BloomOptimized_OnDisable_m01F98DF689CC1FA49D1649FAF6D9605DC58191A3,
	BloomOptimized_OnRenderImage_mDDBA8F4CFCDFFCFF22538ABC9F53E155EEBF2A77,
	BloomOptimized__ctor_m7D12176638B5C95A5B0ECEF237B979071183C59B,
	Blur_get_material_mA78CC6864A1F4CF4F6516E0BE4EC3D7352DCA6F6,
	Blur_OnDisable_m69A77A935D286E9E10A71B4C541FB336433EEF4A,
	Blur_Start_m671E5AA53CB3046B8E1487771D744379D76173BF,
	Blur_FourTapCone_m71056B588F10C15AD455683859B51D6637091CAC,
	Blur_DownSample4x_mA4FCF00C3664CCD8BA7737EAA0B9DFC3AC33C59C,
	Blur_OnRenderImage_m5B3FAA032E4882D594AC0F01B15162807AD81AED,
	Blur__ctor_m2E2A4A2790C17E5FE8A3E6E7BC475026DB462686,
	Blur__cctor_mA73F59B7D2C8520709C0BEF6FA9E117C7B8422CD,
	BlurOptimized_CheckResources_m7C733652AD37CC67CA72018677EC5024A91EB92F,
	BlurOptimized_OnDisable_mFB0A48F457243BAD0CD2978675F17B55AEB70463,
	BlurOptimized_OnRenderImage_m2DA65AD6DB764CC5A3DFFF6017077F3D9C868183,
	BlurOptimized__ctor_mF2CAECAFB429E586A5C9307C29D55F1ABE996A80,
	CameraMotionBlur_CalculateViewProjection_m4113A637085024B08B80F3F69D1945FE738FC1C7,
	CameraMotionBlur_Start_mFBF50D53B01E31653982FDC149B4C26EC5D265B6,
	CameraMotionBlur_OnEnable_mF3AD67713F3FE3172E16E3AF68CF337CE357D899,
	CameraMotionBlur_OnDisable_m5148C966633B3DA9C0C3026B1156C733533E982A,
	CameraMotionBlur_CheckResources_m0986ED800445AE5B192905B47A2C8F1E96CFBFA9,
	CameraMotionBlur_OnRenderImage_m47EBA911A70FAAC719243096B66B750973E9B3D1,
	CameraMotionBlur_Remember_m279B766C194E8B9BB0792E609F55FB9804428F56,
	CameraMotionBlur_GetTmpCam_mD17DD474B53EE2E52E095148D0F081346669A961,
	CameraMotionBlur_StartFrame_m76A202342D32FC72D50FAC86D7EDE201BAF38786,
	CameraMotionBlur_divRoundUp_mD914B62ABFC65F49BBB2AF3C9625ACA3B70898FF,
	CameraMotionBlur__ctor_mAC7F0EF8300A7BAEEEC0D28DD18F6EB28083ECBB,
	CameraMotionBlur__cctor_m937CF6073534212C4EF2CFEDCEAD126D109301BB,
	ColorCorrectionCurves_Start_m8C11CAE0CB57C86CBCE9CB6150A3285A890E23FB,
	ColorCorrectionCurves_Awake_m9098F9B87364FC745D5E957D9AB2C2E0DD111BB3,
	ColorCorrectionCurves_CheckResources_m7B83F97C47F6140212ECB9A2C19A672E8EFC0BCA,
	ColorCorrectionCurves_UpdateParameters_m45A411338A64C382F344CEC47BA7511F41AABD13,
	ColorCorrectionCurves_UpdateTextures_mC4FE3D3103875ABEBFFF09919EC65BD26DC5255D,
	ColorCorrectionCurves_OnRenderImage_m69AA467A32BCED95118DDD711A82BDFBCFA56D7A,
	ColorCorrectionCurves__ctor_m412D7B814A77ECA3A56682C1234E7F7FD1C0C9FB,
	ColorCorrectionLookup_CheckResources_m936445D39C45BCC4500CF220AA5334310A06B94A,
	ColorCorrectionLookup_OnDisable_m02859D332B1470C68820895502D795F9FE374C3A,
	ColorCorrectionLookup_OnDestroy_mA9C80B55F38F8E5BEDFFF807C689F6B3A8D15B73,
	ColorCorrectionLookup_SetIdentityLut_mB972F312081581EA2A8EDE79DC3D98683C26612D,
	ColorCorrectionLookup_ValidDimensions_mCE4FC5CE5F0C7C606DFC73A441443C58D8D68F9A,
	ColorCorrectionLookup_Convert_m6C389BDA8FAE5B0ED75C22416CB94780AC1036CC,
	ColorCorrectionLookup_OnRenderImage_mD0352CEF7EB4F4FF6A0928A950C2A1FE1455572A,
	ColorCorrectionLookup__ctor_mDCF2798253BECF30B5DC894780A83404A542DA8C,
	ColorCorrectionRamp_OnRenderImage_m8BEEBE37D7500310CDF3C081E736ABD03D8D3184,
	ColorCorrectionRamp__ctor_mF21655C19334A48C1E5C7FD256C0173EE74B67A2,
	ContrastEnhance_CheckResources_m4C273D28A003ED045F1A9DF7ABCCCC02CE2C42B3,
	ContrastEnhance_OnRenderImage_m16B76BCF6DB8FE2DFB6692B2138373A7DB7AE0B7,
	ContrastEnhance__ctor_m5494D801101246FF95584EA6745D899389FF06DD,
	ContrastStretch_get_materialLum_m0D02A7A771E1A767717161959DA76D930B586A73,
	ContrastStretch_get_materialReduce_mC351F3F30FC1EFF05E02710BE601B20B45D4721A,
	ContrastStretch_get_materialAdapt_mBCC58882ACA33BE2D972EF3023C585FF43CA9ED6,
	ContrastStretch_get_materialApply_m83520035795F75431A4FA67718EB364A08C6869F,
	ContrastStretch_Start_m37FD7E59064319B99C181B5E441956D9DD805BA9,
	ContrastStretch_OnEnable_mAED566583E7BFDB6D5D675054C93966529444BFA,
	ContrastStretch_OnDisable_mCB3F858ACC8144C26B8502167A6C60508742B329,
	ContrastStretch_OnRenderImage_mD15C826C83ABB903A0FA3191C5D58901FD32EDDA,
	ContrastStretch_CalculateAdaptation_m1FEEEA7976F0A0E1F5B7E03CC6D6B20B3B8F4403,
	ContrastStretch__ctor_mDF0B21BF845EE65245A49F6A40858EDC0325BB7A,
	CreaseShading_CheckResources_mA39D76AD7F4137295B62A3A1E82EBCD0F8014F2F,
	CreaseShading_OnRenderImage_mD67F9FBBE12E54F70230DF539DEA74BA0E5BF4E9,
	CreaseShading__ctor_mF59E60629F82D223EC50BEC164ED8BCC801BEE4D,
	DepthOfField_CheckResources_mFF4623AE1526947893CE07434D56D297CDBA58F8,
	DepthOfField_OnEnable_mD0B0891326524D1173E68F86847C218E6E7DD921,
	DepthOfField_OnDisable_mAE76CEB0CDB7A59FB4D153373F293ABEA56E524E,
	DepthOfField_ReleaseComputeResources_mE1DFEC71DEAACA30A278D8C7554C0316784157A5,
	DepthOfField_CreateComputeResources_m0ADD9C7AA1AA59F482ADB659F3846A915B50B447,
	DepthOfField_FocalDistance01_mB097CA88DA3A6EFF2BCA0ADBE82CFA9609227546,
	DepthOfField_WriteCoc_mA9CFBC6A691FE3AD1C51A9381BA3A77B80A0E913,
	DepthOfField_OnRenderImage_m8806DA4A44BCF3CFA9441A8EC39107D1A5B3B72F,
	DepthOfField__ctor_m2DDFF0431458E06C8C53DD5A797EA6571C02B0E8,
	DepthOfFieldDeprecated_CreateMaterials_m7E864DCC1D3DF384FCC7AE3A394FB61753FC935F,
	DepthOfFieldDeprecated_CheckResources_m57F9DB671AFDAD84ABAFC2412B116AFCED59D545,
	DepthOfFieldDeprecated_OnDisable_mDDB999F017D483B0CFAABEBE17148A1739EEAEA4,
	DepthOfFieldDeprecated_OnEnable_m823BFC708B75CC6E04576D3AD6894A8CF9ED9DF2,
	DepthOfFieldDeprecated_FocalDistance01_mF372E4CACD8CD9CEF57325523577F2728D850809,
	DepthOfFieldDeprecated_GetDividerBasedOnQuality_m4C92DBAE3BF80F98FF128078185BC3675D1EB121,
	DepthOfFieldDeprecated_GetLowResolutionDividerBasedOnQuality_m21AEB48E74DDD5332A180B798BB0BC1895F5680D,
	DepthOfFieldDeprecated_OnRenderImage_m4FD02819120EF0763ABCDA0F26E3F9C082E96595,
	DepthOfFieldDeprecated_Blur_m38AF1CF44891304E473D29FA27EAB2C50195522C,
	DepthOfFieldDeprecated_BlurFg_m831640C176288E0845AB4AB4C0729BF9DA326D7F,
	DepthOfFieldDeprecated_BlurHex_m1DA49B64915A6BFFC8669BF4C811801A05F921D2,
	DepthOfFieldDeprecated_Downsample_m5B5A94F17F06EEC638B8A3B2CB0BF2E8C01761C7,
	DepthOfFieldDeprecated_AddBokeh_mD44A5A7C08642E7FE9DAE6EBE3959841E47700CD,
	DepthOfFieldDeprecated_ReleaseTextures_mBF3F404B9476878E1EECBEF4F11E43D5C435370A,
	DepthOfFieldDeprecated_AllocateTextures_mEEE3303442CEE81510D4AFC573D343199A9CCF38,
	DepthOfFieldDeprecated__ctor_m470B5306F1CEF2BBCA46150B4BDC39523B39E7A8,
	DepthOfFieldDeprecated__cctor_m3FF5D0274DAEA3E0FED59E3315B607FA8CA2F325,
	EdgeDetection_CheckResources_m77968AAE4F770D8519478DD7ECBE4DD7AED1CEFE,
	EdgeDetection_Start_m806A4D2E0B9BF8E9C2E6E185642D4FBC56DDC90C,
	EdgeDetection_SetCameraFlag_mB0E693AE23207D73F1FD8CF254A189189D181FB7,
	EdgeDetection_OnEnable_m6981429E39B47DC1BC6EA398D3540D1C7852D1ED,
	EdgeDetection_OnRenderImage_mE34D4EFE02009C8585D83B8196ACF2EF40A44E85,
	EdgeDetection__ctor_m6819FFBE592107ABA108BC44CC77DC1BF7869893,
	Fisheye_CheckResources_mA77AB76AFD5BCBABAF4544307A7266225A46981B,
	Fisheye_OnRenderImage_m2E866F1F44A61714EF8B3EC6CFEF98E4B9078A6C,
	Fisheye__ctor_m0F4AD162A2EA39B007B1F84756B4A9C646285DA5,
	GlobalFog_CheckResources_mEC1BF4E75C7F7083123AE74494FC72E258787F0C,
	GlobalFog_OnRenderImage_m974B8C5F27B91FCA36B82808377068B6A38A3806,
	GlobalFog__ctor_m884187835D88AE1E1E0FCD1DC8D8389382ABCFED,
	Grayscale_OnRenderImage_mC77D55DCB26C79586251A141ECCEB22A6F0C7C55,
	Grayscale__ctor_m8FC49D53FB6BA407C8F723A43D7DE9DF478652F0,
	ImageEffectBase_Start_m0B8BE75EEF30FB0859184CC585613DC0C8F78914,
	ImageEffectBase_get_material_mA8C588D469CA3BD4912E1134859B2CF27AC910BF,
	ImageEffectBase_OnDisable_mD7017DFB0EA0C265AEBDE9AF4F83334AA9F4753D,
	ImageEffectBase__ctor_mB771C56D15574F48908C288F4C219590311272FF,
	ImageEffects_RenderDistortion_m502BE4AA0D08445AF1037185CCBB47551B103D76,
	ImageEffects_Blit_m6DD0BB12C95116A09D62B3C186FC25D6DFFF6966,
	ImageEffects_BlitWithMaterial_m3C75FB03C841A99760A70344A67B76327E791676,
	ImageEffects__ctor_mBEF21EA29F71955781BC8DCE6B5F6025C58BB28D,
	MotionBlur_Start_mE69D3D0ABF43F66A54054C7891F26089D17AFEE4,
	MotionBlur_OnDisable_mFFEFB4A703090B8ECBAC9753F8E3B041032AF9E3,
	MotionBlur_OnRenderImage_m5BCB2A20A5C35EE5CB974A6B5D1115C120053EB8,
	MotionBlur__ctor_m103E002CBF7AD5898088A5E79A5007C2A770A413,
	NoiseAndGrain_CheckResources_mC8D77D1483367A20E613E5CBBBB00F39D5AD1FB8,
	NoiseAndGrain_OnRenderImage_m5D12B699F5844F55A4004651E1230C1B066A3C18,
	NoiseAndGrain_DrawNoiseQuadGrid_m559228D062603ADF90CA4F710648953C3D4CA363,
	NoiseAndGrain__ctor_mDE68721108A8C7CC3BE0A8DDB1A14D04F586917D,
	NoiseAndGrain__cctor_m75F028DC54C6ADA78CDE97F62B1D7A0A152ED11D,
	NoiseAndScratches_Start_mB15AADF01E6D83CA015C97C28AEDE6568BCC7424,
	NoiseAndScratches_get_material_m1606C8BB8FD10FB2C9AC839ACED40BFB6D354193,
	NoiseAndScratches_OnDisable_mB1BE49CB7E5B744ED0AD4032BE0D4A60ACDF7EC8,
	NoiseAndScratches_SanitizeParameters_m21DE2EAA33D1875E6D27D7588F2392C99B947697,
	NoiseAndScratches_OnRenderImage_m570F49BF4167D67480E3F371F863D46416DDA6B8,
	NoiseAndScratches__ctor_m836D75D0546111B1F1F77EB14D4475E1AC489224,
	PostEffectsBase_CheckShaderAndCreateMaterial_m7EA37EFD394AA82B4D24059D78E9337EAE917A1B,
	PostEffectsBase_CreateMaterial_m7256FCF60E5E7377200668EE705C6FA01B4ED026,
	PostEffectsBase_OnEnable_m21BECBF1006EF102FE6AF8EC9FA9468052723ECE,
	PostEffectsBase_OnDestroy_mCFF1154859A309F1F5A7C6F1F83A11F30EF4E607,
	PostEffectsBase_RemoveCreatedMaterials_m1E4EE64C79DCDD6E2952A69E43AF2A1F7DB2443C,
	PostEffectsBase_CheckSupport_m46DF5BC2831150955600DD98F32069B7A750D032,
	PostEffectsBase_CheckResources_mD1FD25B17E3A3266BF8BF3C4DB54C2322C0450D5,
	PostEffectsBase_Start_m722B325C26402B2C8E1B08419656161373EAE341,
	PostEffectsBase_CheckSupport_mADFD99E7F258D0BB95385FD0D8AFCE7A941AF44A,
	PostEffectsBase_CheckSupport_m5F9E1F82A5FD22657529FAEE8FEC6B800B86BB64,
	PostEffectsBase_Dx11Support_mF74FA1E653FC2BF47BC252B602411EBBCB5264C5,
	PostEffectsBase_ReportAutoDisable_m4EBCB675A21C994DE7AAFEDC02587F07A0162917,
	PostEffectsBase_CheckShader_mFC9D581D608597D8FDC0D1C6DC11509243D25412,
	PostEffectsBase_NotSupported_mB602B43321D89C83568F500F8BD76D0B303D8507,
	PostEffectsBase_DrawBorder_m79DE79BA785A598EB819C0FC1B9E7EB929E46EBF,
	PostEffectsBase__ctor_m78DEC2AC3926DBAE98BDCCC2FD8346DD52E3D7D8,
	PostEffectsHelper_OnRenderImage_m479B964ADE9ABF36AC6203D7594884F508E9FF47,
	PostEffectsHelper_DrawLowLevelPlaneAlignedWithCamera_m92F1ADC8B006801B8CB9E0C966D165D78D51E91B,
	PostEffectsHelper_DrawBorder_m32A1BA6A7D2A1B7D9B5CB9A87739C35593ECE4CF,
	PostEffectsHelper_DrawLowLevelQuad_mBA588FFD508359BB81EAB9DF149B4A3A91E177E5,
	PostEffectsHelper__ctor_m3BA590F71D3CDC362DA541CB562456B7E0AEB1D7,
	Quads_HasMeshes_mCDA1AF7E4D2C0448EB0031D73FC31B3A013D95A9,
	Quads_Cleanup_mC27BEBC330A8E2D9BC2C880A020A28AD5787C919,
	Quads_GetMeshes_mCAD4B92A5E9216F4AE2CD7AC053E57A9040BE71C,
	Quads_GetMesh_m4E7E21533CEB935492A6FBA2C40DA832935B8C66,
	Quads__ctor_m178BAB45871CF3B27D02AF03F0394C618D03EC1A,
	Quads__cctor_m8DF4521108A46E4BC6F4097912E197037A4D5C5C,
	ScreenOverlay_CheckResources_m9652014AC8645005FD46677B491ADB2E49B7C0BF,
	ScreenOverlay_OnRenderImage_m04BA614F8BD5B421DEDEF18BB6C7B2F3C7858DAC,
	ScreenOverlay__ctor_m0D520F2A7539ECA884A34D0351267D8009EB24A7,
	ScreenSpaceAmbientObscurance_CheckResources_m94E6CE933DB0741CDA966B3BD74D87C9C34EB32F,
	ScreenSpaceAmbientObscurance_OnDisable_mF178257C007A4449251E9A800B768040CA6B1901,
	ScreenSpaceAmbientObscurance_OnRenderImage_mAF0FB2C0263ACE051C464F761099E67BA8A50160,
	ScreenSpaceAmbientObscurance__ctor_mB6F187F68D922A42D317BA27A4236BEA1A83A29B,
	ScreenSpaceAmbientOcclusion_CreateMaterial_m91C949BB7E24B74C7DC4B33DE87626425D6CD0E6,
	ScreenSpaceAmbientOcclusion_DestroyMaterial_m520AD4DE19AF81BBD992A242F14AF739B8039823,
	ScreenSpaceAmbientOcclusion_OnDisable_m571DFD1142ECBEF64B097480492F1E69A562A716,
	ScreenSpaceAmbientOcclusion_Start_m20BD4CFC102696D49C7241A3BDFCB734AD988B5B,
	ScreenSpaceAmbientOcclusion_OnEnable_m728A790197D8E897DCD5105052D8D1EC7D78E446,
	ScreenSpaceAmbientOcclusion_CreateMaterials_m21EA33E1E08232AF9B43CEF20D1DB6ABCCADDEFC,
	ScreenSpaceAmbientOcclusion_OnRenderImage_m5212349218E44C8E6D18A25F1AC258961CDAE7A3,
	ScreenSpaceAmbientOcclusion__ctor_mC95EBF095908EFFA435BAA4B928DC0049CBCE6BF,
	SepiaTone_OnRenderImage_mF3B073827862274C0B9B6CEE2C95B39F603FCAB3,
	SepiaTone__ctor_m8DC1DFC72CEEF9AD0EBD6EF708C32446A945B24C,
	SunShafts_CheckResources_m9CFFB8852D2BEF33CAE3405634F51E95E98994DA,
	SunShafts_OnRenderImage_m0B78F16F7D0104E80D0B7155CFA1650AA342897F,
	SunShafts__ctor_m5A50800230C92569BD30CEBC2AE2F41375180A29,
	TiltShift_CheckResources_mD97D41BB18DBF86E79EB9987D66888EE7FBC8ECD,
	TiltShift_OnRenderImage_mC10C49389FF486CAD60C8FE8C3CC3F475DD1B1EA,
	TiltShift__ctor_mB4B5B5D405033F79FEE41B5018C3AAF5074BC1B0,
	Tonemapping_CheckResources_m317B2A029F297AB72AB94B2D5D4E4D2EC5589D7C,
	Tonemapping_UpdateCurve_mD366B0A2F2A1C946C41B989FA6D0DF11E4202D22,
	Tonemapping_OnDisable_m6C1516A147F54C28ECE029814E28440CBA74B5A4,
	Tonemapping_CreateInternalRenderTexture_m9A69666FCE1399CAD7EDAEA4BA2997597D347183,
	Tonemapping_OnRenderImage_m5C3295A239E9113D9A95EE75B6B4D55562DC1A9C,
	Tonemapping__ctor_mE5C67505418D47B6C17FEC1E7B99B0BB8DD5627D,
	Triangles_HasMeshes_mBD1CC9B21E38800033B5B84AB8CD708CCA75EE37,
	Triangles_Cleanup_mEE21C0D422FBBA3EFF7C0863901D831A00F1757C,
	Triangles_GetMeshes_mD5DF8B4F5248C1FEFD695733DD113A18AECDEDDC,
	Triangles_GetMesh_mF19BD126BA8636F5861FBC67CEC2CBEA8DEED962,
	Triangles__ctor_mEDE5B5520FDB64307AE34DD49DA8B3FB49267A96,
	Triangles__cctor_m4CF7CC014DE88B02B2906FB4C947D8DC17D2A4A6,
	Twirl_OnRenderImage_mDC62A58F6242107DF15D252D86AF74E2E4A34980,
	Twirl__ctor_m5E24773FB247B2D4F3377960734EA184026E5A2D,
	VignetteAndChromaticAberration_CheckResources_mAEB75CE9EEE61DD2662CA5C320701A0EE60B63C1,
	VignetteAndChromaticAberration_OnRenderImage_mE0CE6D9AA45DA1650026CD87C01D4956C63573A7,
	VignetteAndChromaticAberration__ctor_m2FD6F170E6CE7256F57A57EA2F6686E937B2A075,
	Vortex_OnRenderImage_mCFBFC02516C719C8D6E8F738EDB2DC1A0E7F8D49,
	Vortex__ctor_m4320E4081F0959DDD299C17445D77D67109D0084,
};
static const int32_t s_InvokerIndices[212] = 
{
	14,
	114,
	27,
	23,
	114,
	27,
	1504,
	27,
	1504,
	1505,
	1504,
	23,
	114,
	27,
	1504,
	27,
	1506,
	1504,
	23,
	114,
	23,
	27,
	23,
	14,
	23,
	23,
	593,
	27,
	27,
	23,
	3,
	114,
	23,
	27,
	23,
	23,
	23,
	23,
	23,
	114,
	27,
	23,
	14,
	23,
	137,
	23,
	3,
	23,
	23,
	114,
	23,
	23,
	27,
	23,
	114,
	23,
	23,
	23,
	9,
	27,
	27,
	23,
	27,
	23,
	114,
	27,
	23,
	14,
	14,
	14,
	14,
	23,
	23,
	23,
	27,
	26,
	23,
	114,
	27,
	23,
	114,
	23,
	23,
	23,
	23,
	1052,
	396,
	27,
	23,
	23,
	114,
	23,
	23,
	1052,
	10,
	37,
	27,
	1507,
	1507,
	1508,
	27,
	168,
	23,
	1509,
	23,
	3,
	114,
	23,
	23,
	23,
	27,
	23,
	114,
	27,
	23,
	114,
	27,
	23,
	27,
	23,
	23,
	14,
	23,
	23,
	1510,
	134,
	156,
	23,
	23,
	23,
	27,
	23,
	114,
	27,
	637,
	23,
	3,
	23,
	14,
	23,
	23,
	27,
	23,
	113,
	113,
	23,
	23,
	23,
	114,
	114,
	23,
	187,
	604,
	114,
	23,
	9,
	23,
	27,
	23,
	27,
	1511,
	134,
	1512,
	23,
	49,
	3,
	525,
	1152,
	23,
	3,
	114,
	27,
	23,
	114,
	23,
	27,
	23,
	0,
	122,
	23,
	23,
	23,
	23,
	27,
	23,
	27,
	23,
	114,
	27,
	23,
	114,
	27,
	23,
	114,
	673,
	23,
	114,
	27,
	23,
	49,
	3,
	525,
	1152,
	23,
	3,
	27,
	23,
	114,
	27,
	23,
	27,
	23,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpU2DfirstpassCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpU2DfirstpassCodeGenModule = 
{
	"Assembly-CSharp-firstpass.dll",
	212,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
