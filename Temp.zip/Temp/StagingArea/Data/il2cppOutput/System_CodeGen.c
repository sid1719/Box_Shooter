﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String SR::GetString(System.String,System.Object[])
extern void SR_GetString_m9548BD6DD52DFDB46372F211078AE57FA2401E39 ();
// 0x00000002 System.String SR::GetString(System.Globalization.CultureInfo,System.String,System.Object[])
extern void SR_GetString_m9D671CBA422B18D15B8FF59B22DCCEB32E3D16E2 ();
// 0x00000003 System.String SR::GetString(System.String)
extern void SR_GetString_m3FC710B15474A9B651DA02B303241B6D8B87E2A7 ();
// 0x00000004 System.Boolean System.IriHelper::CheckIriUnicodeRange(System.Char,System.Boolean)
extern void IriHelper_CheckIriUnicodeRange_mA9BAAD6D244ADEE8986FDC0DFB3DFDA90C093A6C ();
// 0x00000005 System.Boolean System.IriHelper::CheckIriUnicodeRange(System.Char,System.Char,System.Boolean&,System.Boolean)
extern void IriHelper_CheckIriUnicodeRange_m5ED29083C22062AEAB8B5787C9A27CFEEC397AD9 ();
// 0x00000006 System.Boolean System.IriHelper::CheckIsReserved(System.Char,System.UriComponents)
extern void IriHelper_CheckIsReserved_m5C0A35BF0890852A3FC564618DB0836BBB6C0F1C ();
// 0x00000007 System.String System.IriHelper::EscapeUnescapeIri(System.Char*,System.Int32,System.Int32,System.UriComponents)
extern void IriHelper_EscapeUnescapeIri_m6DE347247CE35DB4CE3129BEC2179F0095D69239 ();
// 0x00000008 System.Boolean System.Uri::get_IsImplicitFile()
extern void Uri_get_IsImplicitFile_m048350CB1E9AB92599F1557680A5D3B5FDE7C35D ();
// 0x00000009 System.Boolean System.Uri::get_IsUncOrDosPath()
extern void Uri_get_IsUncOrDosPath_mE372CA996BE5B29DD531D7C6DD1809E17441005E ();
// 0x0000000A System.Boolean System.Uri::get_IsDosPath()
extern void Uri_get_IsDosPath_m89CA4E32381C529502E91872BC89BD18F5419D08 ();
// 0x0000000B System.Uri_Flags System.Uri::get_HostType()
extern void Uri_get_HostType_mBB4EE8652EA19E2FB8C696302D5EBE82F358EC90 ();
// 0x0000000C System.UriParser System.Uri::get_Syntax()
extern void Uri_get_Syntax_m3DB6A5D9E6FC3E0D0A63EA8A4527AF4106F9BD78 ();
// 0x0000000D System.Boolean System.Uri::get_IsNotAbsoluteUri()
extern void Uri_get_IsNotAbsoluteUri_mF9706123EB027C6E9AB263B98CE58CF319A22919 ();
// 0x0000000E System.Boolean System.Uri::IriParsingStatic(System.UriParser)
extern void Uri_IriParsingStatic_m39FC9677B4B9EFBADF814F2EEA58280F35A1D3E5 ();
// 0x0000000F System.Boolean System.Uri::get_AllowIdn()
extern void Uri_get_AllowIdn_mF1833CB700E04D746D75428948BEBC70536E1941 ();
// 0x00000010 System.Boolean System.Uri::AllowIdnStatic(System.UriParser,System.Uri_Flags)
extern void Uri_AllowIdnStatic_mFABD19611F334DF87EC3FF2B9A1FA061CAE3A5C5 ();
// 0x00000011 System.Boolean System.Uri::IsIntranet(System.String)
extern void Uri_IsIntranet_mE98CA41B60FE0D4970737C8B7C81E5C63BFC07E1 ();
// 0x00000012 System.Boolean System.Uri::get_UserDrivenParsing()
extern void Uri_get_UserDrivenParsing_mFF27964894B5C0432C37E425F319D6C915BCDC39 ();
// 0x00000013 System.Void System.Uri::SetUserDrivenParsing()
extern void Uri_SetUserDrivenParsing_m0368CB47B9E9C35CB49B3F02DBE8DFED8756226B ();
// 0x00000014 System.UInt16 System.Uri::get_SecuredPathIndex()
extern void Uri_get_SecuredPathIndex_mC59A2366D6F3667017F677351C4350C9541905AA ();
// 0x00000015 System.Boolean System.Uri::NotAny(System.Uri_Flags)
extern void Uri_NotAny_mC5DC04B72B13D2997B055B9E41FCFEEC1CE5263D ();
// 0x00000016 System.Boolean System.Uri::InFact(System.Uri_Flags)
extern void Uri_InFact_m4CE890C86FA34154A044516D2F3C9463389220D7 ();
// 0x00000017 System.Boolean System.Uri::StaticNotAny(System.Uri_Flags,System.Uri_Flags)
extern void Uri_StaticNotAny_mC07A1201FBE032238FCFA96E9FB5D60AEDACCC5A ();
// 0x00000018 System.Boolean System.Uri::StaticInFact(System.Uri_Flags,System.Uri_Flags)
extern void Uri_StaticInFact_m77BB2AE094534AFD7B9F68683C2A4356A75E39B8 ();
// 0x00000019 System.Uri_UriInfo System.Uri::EnsureUriInfo()
extern void Uri_EnsureUriInfo_m4B46DF8611FA6D20D497D12D00544CFB466DCFA7 ();
// 0x0000001A System.Void System.Uri::EnsureParseRemaining()
extern void Uri_EnsureParseRemaining_m33815B5767FAFADB762F7E39364E6432340F210B ();
// 0x0000001B System.Void System.Uri::EnsureHostString(System.Boolean)
extern void Uri_EnsureHostString_m4BD63AA5A88CA09572A8A7CF3B2EDDE17EF9C720 ();
// 0x0000001C System.Void System.Uri::.ctor(System.String)
extern void Uri__ctor_mBA69907A1D799CD12ED44B611985B25FE4C626A2 ();
// 0x0000001D System.UriFormatException System.Uri::GetException(System.ParsingError)
extern void Uri_GetException_m2E833A8358C84BCF0397341160FADB1164290164 ();
// 0x0000001E System.Void System.Uri::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri__ctor_m020E8051B3C0C9E60D8A868CBA0774B3FFB7C3FF ();
// 0x0000001F System.Void System.Uri::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri_System_Runtime_Serialization_ISerializable_GetObjectData_mD4773E59427820077E86F2B298DA1386028DAC9C ();
// 0x00000020 System.Void System.Uri::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri_GetObjectData_mC8CCD55C21CB624E369258E27A89F363F8271E68 ();
// 0x00000021 System.Boolean System.Uri::StaticIsFile(System.UriParser)
extern void Uri_StaticIsFile_mD270A5F6C8B59AAF6256B4565ABE5917ABA545E3 ();
// 0x00000022 System.Object System.Uri::get_InitializeLock()
extern void Uri_get_InitializeLock_m45D6A11D14958E716715351E52207DCA808F00EE ();
// 0x00000023 System.Void System.Uri::InitializeUriConfig()
extern void Uri_InitializeUriConfig_m1B2F98DF0BB1A48FEB328E9D8BF3C23B32196FE2 ();
// 0x00000024 System.Int32 System.Uri::get_Port()
extern void Uri_get_Port_m4E64AB9B50CCC50E7B1F139D7AF1403FAF97147C ();
// 0x00000025 System.Boolean System.Uri::get_OriginalStringSwitched()
extern void Uri_get_OriginalStringSwitched_m79E1C9F1C4E0ACCC85BB68841C167DDEA15CC72D ();
// 0x00000026 System.String System.Uri::get_OriginalString()
extern void Uri_get_OriginalString_m56099E46276F0A52524347F1F46A2F88E948504F ();
// 0x00000027 System.Boolean System.Uri::get_IsAbsoluteUri()
extern void Uri_get_IsAbsoluteUri_m8C189085F1C675DBC3148AA70C38074EC075D722 ();
// 0x00000028 System.Boolean System.Uri::IsGenDelim(System.Char)
extern void Uri_IsGenDelim_m376CCA5D00D019A69FD746C57D236A54EB9D3CF3 ();
// 0x00000029 System.Boolean System.Uri::IsHexDigit(System.Char)
extern void Uri_IsHexDigit_m3B2881FA99F0B2197F8017E70C3AE6EBF9849836 ();
// 0x0000002A System.Int32 System.Uri::FromHex(System.Char)
extern void Uri_FromHex_m9EAC76A5DBFED86532FF7E1BBD809176337A227B ();
// 0x0000002B System.Int32 System.Uri::GetHashCode()
extern void Uri_GetHashCode_m06066B9059649A690C5B4DE58D32DF227933F515 ();
// 0x0000002C System.String System.Uri::ToString()
extern void Uri_ToString_mB76863E11134B9635149E8E5F59AB75A74A760E2 ();
// 0x0000002D System.Boolean System.Uri::op_Inequality(System.Uri,System.Uri)
extern void Uri_op_Inequality_m07015206F59460E87CDE2A8D303D5712E30A7F6B ();
// 0x0000002E System.Boolean System.Uri::Equals(System.Object)
extern void Uri_Equals_m432A30F5E72A0F2B729AC051892BF9E1F4D26629 ();
// 0x0000002F System.ParsingError System.Uri::ParseScheme(System.String,System.Uri_Flags&,System.UriParser&)
extern void Uri_ParseScheme_m61CAE16F1EC76725E5E0B23B09577F91BB223884 ();
// 0x00000030 System.UriFormatException System.Uri::ParseMinimal()
extern void Uri_ParseMinimal_m35FCFE52F12315DA60733B807E7C0AB408C0A9CF ();
// 0x00000031 System.ParsingError System.Uri::PrivateParseMinimal()
extern void Uri_PrivateParseMinimal_mE1DA461DDA053787906BBEC2BC2B3046B1B329F0 ();
// 0x00000032 System.Void System.Uri::PrivateParseMinimalIri(System.String,System.UInt16)
extern void Uri_PrivateParseMinimalIri_m29F0CA367080586448C648332F59BED0096AB2D0 ();
// 0x00000033 System.Void System.Uri::CreateUriInfo(System.Uri_Flags)
extern void Uri_CreateUriInfo_mC112D6E7002CA014AB6BEA878A66ECC46340FAAF ();
// 0x00000034 System.Void System.Uri::CreateHostString()
extern void Uri_CreateHostString_m6FEC48641D3786D73B50D5DC792804C9A4D70C54 ();
// 0x00000035 System.String System.Uri::CreateHostStringHelper(System.String,System.UInt16,System.UInt16,System.Uri_Flags&,System.String&)
extern void Uri_CreateHostStringHelper_m6C5EEA8BD2CDBCDD8A63FB74D3B801329EDE7BDD ();
// 0x00000036 System.Void System.Uri::GetHostViaCustomSyntax()
extern void Uri_GetHostViaCustomSyntax_mD591A4A615803E70A03D7C75E7C114E4E460AED3 ();
// 0x00000037 System.String System.Uri::GetParts(System.UriComponents,System.UriFormat)
extern void Uri_GetParts_mF5840DC010E6D420EB5A0722320EDAAEA2D0269F ();
// 0x00000038 System.String System.Uri::GetEscapedParts(System.UriComponents)
extern void Uri_GetEscapedParts_m745615124808CB89A18D499988F4425F678938C4 ();
// 0x00000039 System.String System.Uri::GetUnescapedParts(System.UriComponents,System.UriFormat)
extern void Uri_GetUnescapedParts_m051A75B5D2DDAE55F107457CA468EE9A2563FED3 ();
// 0x0000003A System.String System.Uri::ReCreateParts(System.UriComponents,System.UInt16,System.UriFormat)
extern void Uri_ReCreateParts_mF50263ABC7D750E939B57BF61FA48A8762144FD7 ();
// 0x0000003B System.String System.Uri::GetUriPartsFromUserString(System.UriComponents)
extern void Uri_GetUriPartsFromUserString_m95A7794F28625B6AFD514C08765C27CAAE4BD1B6 ();
// 0x0000003C System.Void System.Uri::ParseRemaining()
extern void Uri_ParseRemaining_mBAE0F9850CD84965B3793B17444C677D77D58774 ();
// 0x0000003D System.UInt16 System.Uri::ParseSchemeCheckImplicitFile(System.Char*,System.UInt16,System.ParsingError&,System.Uri_Flags&,System.UriParser&)
extern void Uri_ParseSchemeCheckImplicitFile_m92A658AE6C04E038058AD8E9581A41B06B6D6243 ();
// 0x0000003E System.Boolean System.Uri::CheckKnownSchemes(System.Int64*,System.UInt16,System.UriParser&)
extern void Uri_CheckKnownSchemes_mCA95AE251E7C9208570543B446385BCF2C727E8D ();
// 0x0000003F System.ParsingError System.Uri::CheckSchemeSyntax(System.Char*,System.UInt16,System.UriParser&)
extern void Uri_CheckSchemeSyntax_m1181D9BEA35D9D22852FD2FE815CABB267BA5A8F ();
// 0x00000040 System.UInt16 System.Uri::CheckAuthorityHelper(System.Char*,System.UInt16,System.UInt16,System.ParsingError&,System.Uri_Flags&,System.UriParser,System.String&)
extern void Uri_CheckAuthorityHelper_m5046CE781115A54CAE3ACD2C03987F526A761387 ();
// 0x00000041 System.Void System.Uri::CheckAuthorityHelperHandleDnsIri(System.Char*,System.UInt16,System.Int32,System.Int32,System.Boolean,System.Boolean,System.UriParser,System.String,System.Uri_Flags&,System.Boolean&,System.String&,System.ParsingError&)
extern void Uri_CheckAuthorityHelperHandleDnsIri_m366E36029D4C9A00C0F216055B15F5E4805AED28 ();
// 0x00000042 System.Void System.Uri::CheckAuthorityHelperHandleAnyHostIri(System.Char*,System.Int32,System.Int32,System.Boolean,System.Boolean,System.UriParser,System.Uri_Flags&,System.String&,System.ParsingError&)
extern void Uri_CheckAuthorityHelperHandleAnyHostIri_m76FEA31E3FEDF3D1614987C6484ECF15022AE9D8 ();
// 0x00000043 System.Void System.Uri::FindEndOfComponent(System.String,System.UInt16&,System.UInt16,System.Char)
extern void Uri_FindEndOfComponent_mF276ABD008291C1FDC4B433A2F274058D06D8A6B ();
// 0x00000044 System.Void System.Uri::FindEndOfComponent(System.Char*,System.UInt16&,System.UInt16,System.Char)
extern void Uri_FindEndOfComponent_mDCDF860C405E9F31F7CFE9AFFE7C096812697AEF ();
// 0x00000045 System.Uri_Check System.Uri::CheckCanonical(System.Char*,System.UInt16&,System.UInt16,System.Char)
extern void Uri_CheckCanonical_mED3910E55213D1DFEAA5B33079E3A89D369B10B6 ();
// 0x00000046 System.Char[] System.Uri::GetCanonicalPath(System.Char[],System.Int32&,System.UriFormat)
extern void Uri_GetCanonicalPath_mDE02BFA56EDD09479DDB2A5A50F6DF5210CA73F2 ();
// 0x00000047 System.Void System.Uri::UnescapeOnly(System.Char*,System.Int32,System.Int32&,System.Char,System.Char,System.Char)
extern void Uri_UnescapeOnly_mB8F87981CDD4CFBFCD97EE668FF281CE26453F21 ();
// 0x00000048 System.Char[] System.Uri::Compress(System.Char[],System.UInt16,System.Int32&,System.UriParser)
extern void Uri_Compress_m02224082A9665F07D35AB6EB6E3198642F9E7BCF ();
// 0x00000049 System.Int32 System.Uri::CalculateCaseInsensitiveHashCode(System.String)
extern void Uri_CalculateCaseInsensitiveHashCode_m634FFDF8FCD81DECCB87161B153D1093C0A6FCE4 ();
// 0x0000004A System.Boolean System.Uri::IsLWS(System.Char)
extern void Uri_IsLWS_m7A9F3B969CCEE56B9F98E40F1903C737DA7DF0D6 ();
// 0x0000004B System.Boolean System.Uri::IsAsciiLetter(System.Char)
extern void Uri_IsAsciiLetter_m93435A20DF4DEE153B87B26D07B9963F1BF4F373 ();
// 0x0000004C System.Boolean System.Uri::IsAsciiLetterOrDigit(System.Char)
extern void Uri_IsAsciiLetterOrDigit_mEBA81E735141504B5804F0B3C94EC39B24AF8661 ();
// 0x0000004D System.Boolean System.Uri::IsBidiControlCharacter(System.Char)
extern void Uri_IsBidiControlCharacter_mB14EA5816A434B7CE382EB9ACBD1432916EC341D ();
// 0x0000004E System.String System.Uri::StripBidiControlCharacter(System.Char*,System.Int32,System.Int32)
extern void Uri_StripBidiControlCharacter_m49D782826401F99D943C1AD76A75125879FF332F ();
// 0x0000004F System.Void System.Uri::CreateThis(System.String,System.Boolean,System.UriKind)
extern void Uri_CreateThis_mCB3DC849A426498E9CCD249850CBC69C9D67D864 ();
// 0x00000050 System.Void System.Uri::InitializeUri(System.ParsingError,System.UriKind,System.UriFormatException&)
extern void Uri_InitializeUri_m5D99BD8533F3FAAD479B1193505B5B19B8C2F2DE ();
// 0x00000051 System.Boolean System.Uri::CheckForConfigLoad(System.String)
extern void Uri_CheckForConfigLoad_m13002EFBBFD437183ED0A7FCBE5681C510996B0F ();
// 0x00000052 System.Boolean System.Uri::CheckForUnicode(System.String)
extern void Uri_CheckForUnicode_m78E4938E82EE352BD5D8493AE0314224BC2543CD ();
// 0x00000053 System.Boolean System.Uri::CheckForEscapedUnreserved(System.String)
extern void Uri_CheckForEscapedUnreserved_mFE708A44EC74C7E773B96B82CD9A5DF25EF97D4A ();
// 0x00000054 System.Boolean System.Uri::TryCreate(System.String,System.UriKind,System.Uri&)
extern void Uri_TryCreate_mEEB6736FEDAF52AAE36ACC1EA1EC8CEBB7C52DAB ();
// 0x00000055 System.String System.Uri::GetComponents(System.UriComponents,System.UriFormat)
extern void Uri_GetComponents_m0346CA8037531DE1FC630775E0BD1F5D1E7920B6 ();
// 0x00000056 System.String System.Uri::UnescapeDataString(System.String)
extern void Uri_UnescapeDataString_mE1F40FC5CA3FF03DEE9EB01E3D8BD502D36A284D ();
// 0x00000057 System.String System.Uri::EscapeUnescapeIri(System.String,System.Int32,System.Int32,System.UriComponents)
extern void Uri_EscapeUnescapeIri_mDE5E4BAE74E2C2373AD186732FEE7AD6E0EA7180 ();
// 0x00000058 System.Void System.Uri::.ctor(System.Uri_Flags,System.UriParser,System.String)
extern void Uri__ctor_m4605489523A7A973459720C1BBE4039FD10557CD ();
// 0x00000059 System.Uri System.Uri::CreateHelper(System.String,System.Boolean,System.UriKind,System.UriFormatException&)
extern void Uri_CreateHelper_m024137C47351CA9959E4AC66F9443AEEE87D89C0 ();
// 0x0000005A System.String System.Uri::GetRelativeSerializationString(System.UriFormat)
extern void Uri_GetRelativeSerializationString_m5D0CD02E255BB96532F056BB382CF7D74D62BE58 ();
// 0x0000005B System.String System.Uri::GetComponentsHelper(System.UriComponents,System.UriFormat)
extern void Uri_GetComponentsHelper_m28B0D80FD94A40685C0F70652AB26755C457B2D3 ();
// 0x0000005C System.Void System.Uri::.cctor()
extern void Uri__cctor_m2B8179039C09C64936CF8262E3EF4A7E7C2F90F2 ();
// 0x0000005D System.Void System.Uri_UriInfo::.ctor()
extern void UriInfo__ctor_m24EFE7B4E03C9FFB8B797770D626680947C87D98 ();
// 0x0000005E System.Void System.Uri_MoreInfo::.ctor()
extern void MoreInfo__ctor_mFE29F028646C12EDCAF7F0F78F9A85D52C10B83C ();
// 0x0000005F System.Void System.UriFormatException::.ctor()
extern void UriFormatException__ctor_mBA5F8C423C09F600B1AF895521C892EA356CA424 ();
// 0x00000060 System.Void System.UriFormatException::.ctor(System.String)
extern void UriFormatException__ctor_mE1D46962CC168EB07B59D1265F5734A8F587567D ();
// 0x00000061 System.Void System.UriFormatException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void UriFormatException__ctor_mE7F5B073E9F9DB5F22536C54959BEB0D1E7DA1D5 ();
// 0x00000062 System.Void System.UriFormatException::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_mED4C06AC35B7F94955ECC0D8F00383888C1127DC ();
// 0x00000063 System.Char[] System.UriHelper::EscapeString(System.String,System.Int32,System.Int32,System.Char[],System.Int32&,System.Boolean,System.Char,System.Char,System.Char)
extern void UriHelper_EscapeString_mF0077A016F05127923308DF7E7E99BD7B9837E8B ();
// 0x00000064 System.Char[] System.UriHelper::EnsureDestinationSize(System.Char*,System.Char[],System.Int32,System.Int16,System.Int16,System.Int32&,System.Int32)
extern void UriHelper_EnsureDestinationSize_m64F4907D0411AAAD1C05E0AD0D2EB120DCBA9217 ();
// 0x00000065 System.Char[] System.UriHelper::UnescapeString(System.String,System.Int32,System.Int32,System.Char[],System.Int32&,System.Char,System.Char,System.Char,System.UnescapeMode,System.UriParser,System.Boolean)
extern void UriHelper_UnescapeString_mC172F713349E3D22985A92BC4F5B51D0BCEE61AF ();
// 0x00000066 System.Char[] System.UriHelper::UnescapeString(System.Char*,System.Int32,System.Int32,System.Char[],System.Int32&,System.Char,System.Char,System.Char,System.UnescapeMode,System.UriParser,System.Boolean)
extern void UriHelper_UnescapeString_mD4815AEAF34E25D31AA4BB4A76B88055F0A49E89 ();
// 0x00000067 System.Void System.UriHelper::MatchUTF8Sequence(System.Char*,System.Char[],System.Int32&,System.Char[],System.Int32,System.Byte[],System.Int32,System.Boolean,System.Boolean)
extern void UriHelper_MatchUTF8Sequence_m4835D9BB77C2701643B14D6FFD3D7057F8C9007F ();
// 0x00000068 System.Void System.UriHelper::EscapeAsciiChar(System.Char,System.Char[],System.Int32&)
extern void UriHelper_EscapeAsciiChar_mFD7DE796BD53CBD2B1E73080FE0346D37F358902 ();
// 0x00000069 System.Char System.UriHelper::EscapedAscii(System.Char,System.Char)
extern void UriHelper_EscapedAscii_m06D556717795E649EBBB30E4CBCF3D221C1FEB78 ();
// 0x0000006A System.Boolean System.UriHelper::IsNotSafeForUnescape(System.Char)
extern void UriHelper_IsNotSafeForUnescape_m1D0461E7C5A3CFBD7A2A7F7322B66BC68CCE741D ();
// 0x0000006B System.Boolean System.UriHelper::IsReservedUnreservedOrHash(System.Char)
extern void UriHelper_IsReservedUnreservedOrHash_m3D7256DABA7F540F8D379FC1D1C54F1C63E46059 ();
// 0x0000006C System.Boolean System.UriHelper::IsUnreserved(System.Char)
extern void UriHelper_IsUnreserved_mAADC7DCEEA864AFB49311696ABBDD76811FAAE48 ();
// 0x0000006D System.Boolean System.UriHelper::Is3986Unreserved(System.Char)
extern void UriHelper_Is3986Unreserved_m3799F2ADA8C63DDB4995F82B974C8EC1DEEBA76A ();
// 0x0000006E System.Void System.UriHelper::.cctor()
extern void UriHelper__cctor_m9537B8AAAA1D6EF77D29A179EC79F5511C662F27 ();
// 0x0000006F System.String System.UriParser::get_SchemeName()
extern void UriParser_get_SchemeName_mFC9EFD71512A64E640866792CCB7DAC5187DE9F1 ();
// 0x00000070 System.Int32 System.UriParser::get_DefaultPort()
extern void UriParser_get_DefaultPort_m050510870CCD4DD08DF7E98E2AF3D616446AD99D ();
// 0x00000071 System.UriParser System.UriParser::OnNewUri()
extern void UriParser_OnNewUri_m7D55337A7A9B6B67FB0AD7CA96F472751EF5A897 ();
// 0x00000072 System.Void System.UriParser::InitializeAndValidate(System.Uri,System.UriFormatException&)
extern void UriParser_InitializeAndValidate_m3E31D86FEE445E313BB7141F760626301767A0E0 ();
// 0x00000073 System.String System.UriParser::GetComponents(System.Uri,System.UriComponents,System.UriFormat)
extern void UriParser_GetComponents_m8A226F43638FA7CD135A651CDE3D4E475E8FC181 ();
// 0x00000074 System.Boolean System.UriParser::get_ShouldUseLegacyV2Quirks()
extern void UriParser_get_ShouldUseLegacyV2Quirks_mD4C8DF67677ACCCC3B5E026099ECC0BDA24D96DD ();
// 0x00000075 System.Void System.UriParser::.cctor()
extern void UriParser__cctor_m00C2855D5C8C07790C5627BBB90AC84A7E8B6BC2 ();
// 0x00000076 System.UriSyntaxFlags System.UriParser::get_Flags()
extern void UriParser_get_Flags_mBCF4C3E94892F00B6E8856BFED1B650FB6A0C039 ();
// 0x00000077 System.Boolean System.UriParser::NotAny(System.UriSyntaxFlags)
extern void UriParser_NotAny_mC998A35DC290F35FFAFFB6A8B66C7B881F2559D3 ();
// 0x00000078 System.Boolean System.UriParser::InFact(System.UriSyntaxFlags)
extern void UriParser_InFact_mDD42FA932B6830D99AA04C2AE7875BA5067C86F3 ();
// 0x00000079 System.Boolean System.UriParser::IsAllSet(System.UriSyntaxFlags)
extern void UriParser_IsAllSet_m74BEC412DC8AF3B1A33E11964EBB3164D9D8C77E ();
// 0x0000007A System.Boolean System.UriParser::IsFullMatch(System.UriSyntaxFlags,System.UriSyntaxFlags)
extern void UriParser_IsFullMatch_m7B5F47A62FA721E550C5439FAA4C6AFAC34EB23E ();
// 0x0000007B System.Void System.UriParser::.ctor(System.UriSyntaxFlags)
extern void UriParser__ctor_mAF168F2B88BC5301B722C1BAAD45E381FBA22E3D ();
// 0x0000007C System.UriParser System.UriParser::FindOrFetchAsUnknownV1Syntax(System.String)
extern void UriParser_FindOrFetchAsUnknownV1Syntax_m3A57CA15FE27DC7982F186E8321B810B56EBD9AD ();
// 0x0000007D System.Boolean System.UriParser::get_IsSimple()
extern void UriParser_get_IsSimple_mDDB03A5F6EEE6E92926A386655E5BBD553719B9C ();
// 0x0000007E System.UriParser System.UriParser::InternalOnNewUri()
extern void UriParser_InternalOnNewUri_m7D55F5CD59A3B9BF57BC68F715A27CC1A44566CA ();
// 0x0000007F System.Void System.UriParser::InternalValidate(System.Uri,System.UriFormatException&)
extern void UriParser_InternalValidate_mF2FEB0E76E48B621EB2058FBE7DCC6A42A1681E2 ();
// 0x00000080 System.String System.UriParser::InternalGetComponents(System.Uri,System.UriComponents,System.UriFormat)
extern void UriParser_InternalGetComponents_mFD4B211C71E0506AE4E4E99D92ECAF1780CE4674 ();
// 0x00000081 System.Void System.UriParser_BuiltInUriParser::.ctor(System.String,System.Int32,System.UriSyntaxFlags)
extern void BuiltInUriParser__ctor_m66250DC53CE01410149D46279D0B413FC1C5CA1C ();
// 0x00000082 System.String System.DomainNameHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void DomainNameHelper_ParseCanonicalName_mFE738FD1237E2D9D9A1B27BA73F58B1689D451E4 ();
// 0x00000083 System.Boolean System.DomainNameHelper::IsValid(System.Char*,System.UInt16,System.Int32&,System.Boolean&,System.Boolean)
extern void DomainNameHelper_IsValid_mE9672A824F71E32116358C5FA029789855A4B461 ();
// 0x00000084 System.Boolean System.DomainNameHelper::IsValidByIri(System.Char*,System.UInt16,System.Int32&,System.Boolean&,System.Boolean)
extern void DomainNameHelper_IsValidByIri_m13E2A6D9EBD42326C096F2423DBB0014763D47BF ();
// 0x00000085 System.String System.DomainNameHelper::IdnEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.Boolean&)
extern void DomainNameHelper_IdnEquivalent_m439593BAF7C6C801F577E7C27B0C4FBB1772E49F ();
// 0x00000086 System.String System.DomainNameHelper::IdnEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.String&)
extern void DomainNameHelper_IdnEquivalent_m459BFF3040F8E6BFE1CE1C6432A1343A2ECF2F57 ();
// 0x00000087 System.Boolean System.DomainNameHelper::IsIdnAce(System.String,System.Int32)
extern void DomainNameHelper_IsIdnAce_m2231C778C4CCE141ACDC412737642CC365307445 ();
// 0x00000088 System.Boolean System.DomainNameHelper::IsIdnAce(System.Char*,System.Int32)
extern void DomainNameHelper_IsIdnAce_m9193B7D824FC6965820FCE980FEE3E0B40EA94B8 ();
// 0x00000089 System.String System.DomainNameHelper::UnicodeEquivalent(System.String,System.Char*,System.Int32,System.Int32)
extern void DomainNameHelper_UnicodeEquivalent_mA80E5FF3AD6AFBB9FC257ED1C4F0D31C8F0EFEC3 ();
// 0x0000008A System.String System.DomainNameHelper::UnicodeEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.Boolean&)
extern void DomainNameHelper_UnicodeEquivalent_mD5A7A659B82F1FBF7ABF30009117CFBF8BC4D55F ();
// 0x0000008B System.Boolean System.DomainNameHelper::IsASCIILetterOrDigit(System.Char,System.Boolean&)
extern void DomainNameHelper_IsASCIILetterOrDigit_mD3B0B9BD4573FADEF6AC7330A5EC58C220455F01 ();
// 0x0000008C System.Boolean System.DomainNameHelper::IsValidDomainLabelCharacter(System.Char,System.Boolean&)
extern void DomainNameHelper_IsValidDomainLabelCharacter_mF6DEB20D9D03A8728B1C58006C40D6603B7D61D1 ();
// 0x0000008D System.String System.IPv4AddressHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void IPv4AddressHelper_ParseCanonicalName_m2A8C35045CE02D6FC2C4251F239D1C0074E0E813 ();
// 0x0000008E System.Int32 System.IPv4AddressHelper::ParseHostNumber(System.String,System.Int32,System.Int32)
extern void IPv4AddressHelper_ParseHostNumber_m798FB6828971F70775D1125565A1D1025C897F14 ();
// 0x0000008F System.Boolean System.IPv4AddressHelper::IsValid(System.Char*,System.Int32,System.Int32&,System.Boolean,System.Boolean,System.Boolean)
extern void IPv4AddressHelper_IsValid_mD96D91E0F3830414F4601A4521E71DE832A45843 ();
// 0x00000090 System.Boolean System.IPv4AddressHelper::IsValidCanonical(System.Char*,System.Int32,System.Int32&,System.Boolean,System.Boolean)
extern void IPv4AddressHelper_IsValidCanonical_mC27E31F1F043D68BC52719892D34EDDC7851B120 ();
// 0x00000091 System.Int64 System.IPv4AddressHelper::ParseNonCanonical(System.Char*,System.Int32,System.Int32&,System.Boolean)
extern void IPv4AddressHelper_ParseNonCanonical_mDCD1CD7FB85C4FFBF3070B1435A0D632C1A7B97E ();
// 0x00000092 System.Boolean System.IPv4AddressHelper::Parse(System.String,System.Byte*,System.Int32,System.Int32)
extern void IPv4AddressHelper_Parse_m08110623FAC14806376148D7C16AB95A428EA6CF ();
// 0x00000093 System.Boolean System.IPv4AddressHelper::ParseCanonical(System.String,System.Byte*,System.Int32,System.Int32)
extern void IPv4AddressHelper_ParseCanonical_m9D4552558C934E373D188DDA0BC1D1DEF5A62C33 ();
// 0x00000094 System.String System.IPv6AddressHelper::ParseCanonicalName(System.String,System.Int32,System.Boolean&,System.String&)
extern void IPv6AddressHelper_ParseCanonicalName_m3944530A7B686031653F97824EF712424E0BEE14 ();
// 0x00000095 System.String System.IPv6AddressHelper::CreateCanonicalName(System.UInt16*)
extern void IPv6AddressHelper_CreateCanonicalName_m0B1C201DFADBEB58869E0BE8BFA967EEE64B096A ();
// 0x00000096 System.Collections.Generic.KeyValuePair`2<System.Int32,System.Int32> System.IPv6AddressHelper::FindCompressionRange(System.UInt16*)
extern void IPv6AddressHelper_FindCompressionRange_mE70B131DDA05D3059325246A5AB7F6029B6EF6BD ();
// 0x00000097 System.Boolean System.IPv6AddressHelper::ShouldHaveIpv4Embedded(System.UInt16*)
extern void IPv6AddressHelper_ShouldHaveIpv4Embedded_m262634E9099141536C00213C1CFC123665A641DE ();
// 0x00000098 System.Boolean System.IPv6AddressHelper::InternalIsValid(System.Char*,System.Int32,System.Int32&,System.Boolean)
extern void IPv6AddressHelper_InternalIsValid_m3BD7E7524455146D4464037DA3B65530E547AB7A ();
// 0x00000099 System.Boolean System.IPv6AddressHelper::IsValid(System.Char*,System.Int32,System.Int32&)
extern void IPv6AddressHelper_IsValid_m2383F1A867665B04A4F2B8D82FF2B62BE51C2289 ();
// 0x0000009A System.Boolean System.IPv6AddressHelper::Parse(System.String,System.UInt16*,System.Int32,System.String&)
extern void IPv6AddressHelper_Parse_m36CE2F56465C4F9F7791E80E954C7C0ECBD16DFB ();
// 0x0000009B System.String System.UncNameHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void UncNameHelper_ParseCanonicalName_mCBE64015FD1B6B4829CEAA89625C1D44E280E37E ();
// 0x0000009C System.Boolean System.UncNameHelper::IsValid(System.Char*,System.UInt16,System.Int32&,System.Boolean)
extern void UncNameHelper_IsValid_m4055361D79684EE7B098C055B2E9068EE06F1EF6 ();
// 0x0000009D System.Void System.IOAsyncCallback::.ctor(System.Object,System.IntPtr)
extern void IOAsyncCallback__ctor_m1010BF5234B0ECC2FEB54105BA15B313633C1985 ();
// 0x0000009E System.Void System.IOAsyncCallback::Invoke(System.IOAsyncResult)
extern void IOAsyncCallback_Invoke_mB95F7E7F0E8326CE5364A30F42FC1073B0AB2D8B ();
// 0x0000009F System.IAsyncResult System.IOAsyncCallback::BeginInvoke(System.IOAsyncResult,System.AsyncCallback,System.Object)
extern void IOAsyncCallback_BeginInvoke_mB8CACF8990B91DF4A695E597CEBE4BA09354C32C ();
// 0x000000A0 System.Void System.IOAsyncCallback::EndInvoke(System.IAsyncResult)
extern void IOAsyncCallback_EndInvoke_m397237D5497A9029CC3FACE692D11BDC1558A727 ();
// 0x000000A1 System.Void System.UriTypeConverter::.ctor()
extern void UriTypeConverter__ctor_m1CAEEF1C615B28212B83C76D892938E0A77D3A64 ();
// 0x000000A2 System.Int64 System.Diagnostics.Stopwatch::GetTimestamp()
extern void Stopwatch_GetTimestamp_m7A4B2D144D880343DB783326F36F6996C1D1A1CA ();
// 0x000000A3 System.Void System.Diagnostics.Stopwatch::.ctor()
extern void Stopwatch__ctor_mA301E9A9D03758CBE09171E0C140CCD06BC9F860 ();
// 0x000000A4 System.TimeSpan System.Diagnostics.Stopwatch::get_Elapsed()
extern void Stopwatch_get_Elapsed_m6735B32BFB466FC4F52112AC3493D37404D184BB ();
// 0x000000A5 System.Int64 System.Diagnostics.Stopwatch::get_ElapsedMilliseconds()
extern void Stopwatch_get_ElapsedMilliseconds_mE39424FB61C885BCFCC4B583C58A8630C3AD8177 ();
// 0x000000A6 System.Int64 System.Diagnostics.Stopwatch::get_ElapsedTicks()
extern void Stopwatch_get_ElapsedTicks_mABB4710231090C75F057E90A29C71C553077A901 ();
// 0x000000A7 System.Void System.Diagnostics.Stopwatch::Start()
extern void Stopwatch_Start_mF61332B96D7753ADA18366A29E22E2A92E25739A ();
// 0x000000A8 System.Void System.Diagnostics.Stopwatch::.cctor()
extern void Stopwatch__cctor_m137C0B2E7182FAEA6E030CD1EDC909E5A3F7A064 ();
// 0x000000A9 System.Void System.ComponentModel.ArrayConverter::.ctor()
extern void ArrayConverter__ctor_m831D145364A55A155BC896935367961A476D53B7 ();
// 0x000000AA System.Void System.ComponentModel.BooleanConverter::.ctor()
extern void BooleanConverter__ctor_m8293C29BCB7B90516FFE978C6295C0378C1BFEE4 ();
// 0x000000AB System.Void System.ComponentModel.CollectionConverter::.ctor()
extern void CollectionConverter__ctor_m86DBE477F4462418329C5CFB45C86A9420F852E7 ();
// 0x000000AC System.Void System.ComponentModel.DecimalConverter::.ctor()
extern void DecimalConverter__ctor_mB015B3871CF834D0C5D8290C9FD15509249921E7 ();
// 0x000000AD System.Void System.ComponentModel.DoubleConverter::.ctor()
extern void DoubleConverter__ctor_m419F1E782FFBC765D22792D76E56D54FC94E6AEB ();
// 0x000000AE System.Void System.ComponentModel.EditorBrowsableAttribute::.ctor(System.ComponentModel.EditorBrowsableState)
extern void EditorBrowsableAttribute__ctor_mACDE45DF0DCAA6E923120D6AEC45422AEF958C2E ();
// 0x000000AF System.Boolean System.ComponentModel.EditorBrowsableAttribute::Equals(System.Object)
extern void EditorBrowsableAttribute_Equals_m6F5EF9CC298CBDC862CBCA5187379A79635726FA ();
// 0x000000B0 System.Int32 System.ComponentModel.EditorBrowsableAttribute::GetHashCode()
extern void EditorBrowsableAttribute_GetHashCode_m74229847CE44E771F282E2E73FFC4DE55771A1B6 ();
// 0x000000B1 System.Void System.ComponentModel.EnumConverter::.ctor(System.Type)
extern void EnumConverter__ctor_mBA8B2E210D061A3CF86950F6D797E911A2E3C774 ();
// 0x000000B2 System.Void System.ComponentModel.Int16Converter::.ctor()
extern void Int16Converter__ctor_mD4D022096E6FB9FFDB84D879E31177A892DD072D ();
// 0x000000B3 System.Void System.ComponentModel.Int32Converter::.ctor()
extern void Int32Converter__ctor_m1CD79AE5880FDE2EC91F1D67E567AAA3618D19B9 ();
// 0x000000B4 System.Void System.ComponentModel.Int64Converter::.ctor()
extern void Int64Converter__ctor_mE4DC71A97EF110B854F22A48AB0F0D3792B53A74 ();
// 0x000000B5 System.Void System.ComponentModel.SingleConverter::.ctor()
extern void SingleConverter__ctor_m8EA7D412C3EE9A9522E7592774DD46EBC6118AA8 ();
// 0x000000B6 System.Void System.ComponentModel.StringConverter::.ctor()
extern void StringConverter__ctor_m2718AC00691AF4A3AF8A8D64896BE3B5D58658B2 ();
// 0x000000B7 System.Void System.ComponentModel.TimeSpanConverter::.ctor()
extern void TimeSpanConverter__ctor_m28E7294174F979EF86FEF9511474B0AB9431217B ();
// 0x000000B8 System.Void System.ComponentModel.TypeConverter::.ctor()
extern void TypeConverter__ctor_m7F8A006E775CCB83A8ACB042B296E48B0AE501CD ();
// 0x000000B9 System.Void System.ComponentModel.TypeConverterAttribute::.ctor()
extern void TypeConverterAttribute__ctor_mD0795A29B6FD59978CAAC6DAF3AC7EC564C519A5 ();
// 0x000000BA System.Void System.ComponentModel.TypeConverterAttribute::.ctor(System.Type)
extern void TypeConverterAttribute__ctor_m52D4E66A914F1A04F2F10A7131A701670225D41C ();
// 0x000000BB System.String System.ComponentModel.TypeConverterAttribute::get_ConverterTypeName()
extern void TypeConverterAttribute_get_ConverterTypeName_m883941C77E14FC5B4A3E32DD8F59F11739D5D6D8 ();
// 0x000000BC System.Boolean System.ComponentModel.TypeConverterAttribute::Equals(System.Object)
extern void TypeConverterAttribute_Equals_mDA74DFC28CC7ABC315407EDD1AAC14531C5F6AC4 ();
// 0x000000BD System.Int32 System.ComponentModel.TypeConverterAttribute::GetHashCode()
extern void TypeConverterAttribute_GetHashCode_m35874D49724DA3F72C6C2575FD595A711A659DAA ();
// 0x000000BE System.Void System.ComponentModel.TypeConverterAttribute::.cctor()
extern void TypeConverterAttribute__cctor_mB1A775F56A5933A17CF349BD466B0CCE66B1078A ();
// 0x000000BF System.Void System.ComponentModel.Win32Exception::.ctor()
extern void Win32Exception__ctor_mC03E215A1695ED64DDC50F4BE9F59966974DF759 ();
// 0x000000C0 System.Void System.ComponentModel.Win32Exception::.ctor(System.Int32)
extern void Win32Exception__ctor_m2BEA755F6AA536ADDDF07D83BD8297F02584F714 ();
// 0x000000C1 System.Void System.ComponentModel.Win32Exception::.ctor(System.Int32,System.String)
extern void Win32Exception__ctor_m94A043EE26097BBFE0ED22FD4EBEA357F142EFE6 ();
// 0x000000C2 System.Void System.ComponentModel.Win32Exception::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Win32Exception__ctor_mC7ADDE9D2FEE4E17432F63C24EF1D872380094DB ();
// 0x000000C3 System.Void System.ComponentModel.Win32Exception::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Win32Exception_GetObjectData_m7CD0D7A0806E4A9D8E78ADCBC616700379AB79E8 ();
// 0x000000C4 System.String System.ComponentModel.Win32Exception::GetErrorMessage(System.Int32)
extern void Win32Exception_GetErrorMessage_m6085687D868718B45289CB6AF6EDCB7F89D7350D ();
// 0x000000C5 System.Void System.ComponentModel.Win32Exception::InitializeErrorMessages()
extern void Win32Exception_InitializeErrorMessages_m4FE6F56C1C2CCB3F6468F0F9F5AD6E1B08673438 ();
// 0x000000C6 System.Void System.ComponentModel.Win32Exception::.cctor()
extern void Win32Exception__cctor_m800CD9D0B3E3253B79A19B6646A7D28B29C3FC52 ();
// 0x000000C7 System.Void System.ComponentModel.BaseNumberConverter::.ctor()
extern void BaseNumberConverter__ctor_mD78E1C7E1F8A977BC7AD33DB0C1E5E32C60E8E83 ();
// 0x000000C8 System.Void System.Security.Cryptography.Oid::.ctor(System.String)
extern void Oid__ctor_m45F49EB1ABFD4F3EB0FC9729C76FF83995752743 ();
// 0x000000C9 System.Void System.Security.Cryptography.Oid::.ctor(System.String,System.Security.Cryptography.OidGroup,System.Boolean)
extern void Oid__ctor_m67437A59D4E75ABF6E40D503F57F81199546E5EC ();
// 0x000000CA System.Void System.Security.Cryptography.Oid::.ctor(System.String,System.String)
extern void Oid__ctor_m0656E1FC1A7E7BBF694A568DDDF8BE4AFA544985 ();
// 0x000000CB System.Void System.Security.Cryptography.Oid::.ctor(System.Security.Cryptography.Oid)
extern void Oid__ctor_mA7AFE14DF30B47447BFFC9E41B37B8DB46C9D079 ();
// 0x000000CC System.String System.Security.Cryptography.Oid::get_Value()
extern void Oid_get_Value_mFE18BDFF095DD5A6643F4FEC3E57846716F37F05 ();
// 0x000000CD System.Void System.Security.Cryptography.Oid::set_Value(System.String)
extern void Oid_set_Value_m304CEF248379566701402100FA015EAC640C033F ();
// 0x000000CE System.Void System.Security.Cryptography.OidCollection::.ctor()
extern void OidCollection__ctor_m99B93BB5B35BF7A395CFB7F8B155DFA8DD734800 ();
// 0x000000CF System.Int32 System.Security.Cryptography.OidCollection::Add(System.Security.Cryptography.Oid)
extern void OidCollection_Add_m1FF686421A22A86F8296259D99DA38E02B8BBF5C ();
// 0x000000D0 System.Security.Cryptography.Oid System.Security.Cryptography.OidCollection::get_Item(System.Int32)
extern void OidCollection_get_Item_mB37F923F4714BFE0DF44E8EE4A1A5EA1F3EBB1D9 ();
// 0x000000D1 System.Int32 System.Security.Cryptography.OidCollection::get_Count()
extern void OidCollection_get_Count_m6AC0709CDD68451F4CAC942CE94A5A97F3C294B2 ();
// 0x000000D2 System.Collections.IEnumerator System.Security.Cryptography.OidCollection::System.Collections.IEnumerable.GetEnumerator()
extern void OidCollection_System_Collections_IEnumerable_GetEnumerator_m3FD3A96DFF93BD88A3B28E35A4DEF57AF25ECB30 ();
// 0x000000D3 System.Void System.Security.Cryptography.OidCollection::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
extern void OidCollection_System_Collections_ICollection_CopyTo_mE508CB1FD9E56CCFE5A4BDD5251D815BF78AC5A9 ();
// 0x000000D4 System.Void System.Security.Cryptography.OidEnumerator::.ctor(System.Security.Cryptography.OidCollection)
extern void OidEnumerator__ctor_mCA4FBC8408E2B04FD0A524E256E284E8A44E0797 ();
// 0x000000D5 System.Object System.Security.Cryptography.OidEnumerator::System.Collections.IEnumerator.get_Current()
extern void OidEnumerator_System_Collections_IEnumerator_get_Current_mF11B1F886842EA79EDB215BD5106D0C4C65EBE53 ();
// 0x000000D6 System.Boolean System.Security.Cryptography.OidEnumerator::MoveNext()
extern void OidEnumerator_MoveNext_m073D94D5D3254D53DF53429ACAD0AA9BD682221D ();
// 0x000000D7 System.Void System.Security.Cryptography.OidEnumerator::Reset()
extern void OidEnumerator_Reset_m5006C3B1283711E2BDDEA6C25FDF93BBB900195E ();
// 0x000000D8 System.String System.Security.Cryptography.CAPI::CryptFindOIDInfoNameFromKey(System.String,System.Security.Cryptography.OidGroup)
extern void CAPI_CryptFindOIDInfoNameFromKey_mA2FD2F391E133E586BC8B827DD916613B590E698 ();
// 0x000000D9 System.String System.Security.Cryptography.CAPI::CryptFindOIDInfoKeyFromName(System.String,System.Security.Cryptography.OidGroup)
extern void CAPI_CryptFindOIDInfoKeyFromName_m7809CD491D913D58FA1B996B835A0A91C413E9DB ();
// 0x000000DA System.Void System.Security.Cryptography.AsnEncodedData::.ctor()
extern void AsnEncodedData__ctor_mED24E9D1F11942741819652302C0531D18C39BE6 ();
// 0x000000DB System.Void System.Security.Cryptography.AsnEncodedData::set_Oid(System.Security.Cryptography.Oid)
extern void AsnEncodedData_set_Oid_m91E38503AAFD8E6FD98970D94FD43E7A738242A6 ();
// 0x000000DC System.Byte[] System.Security.Cryptography.AsnEncodedData::get_RawData()
extern void AsnEncodedData_get_RawData_mB9F8281A96011161C67EB3A9208E26C423B187EC ();
// 0x000000DD System.Void System.Security.Cryptography.AsnEncodedData::set_RawData(System.Byte[])
extern void AsnEncodedData_set_RawData_mD7FE2383373A6AF578A4983999D677B58BD6B4EC ();
// 0x000000DE System.Void System.Security.Cryptography.AsnEncodedData::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void AsnEncodedData_CopyFrom_m3937C7ACC425960B8E48B7D2EB50E9417A7CD4B7 ();
// 0x000000DF System.String System.Security.Cryptography.AsnEncodedData::ToString(System.Boolean)
extern void AsnEncodedData_ToString_m502785F2F8B4D1EBDF5CEE612FD8D0C2044390D7 ();
// 0x000000E0 System.String System.Security.Cryptography.AsnEncodedData::Default(System.Boolean)
extern void AsnEncodedData_Default_mEEA94BA253ED1B8A719466A8152A5333E0E3FF07 ();
// 0x000000E1 System.String System.Security.Cryptography.AsnEncodedData::BasicConstraintsExtension(System.Boolean)
extern void AsnEncodedData_BasicConstraintsExtension_m64D690A2456E16AF39F6F0784CE74BC9533BB182 ();
// 0x000000E2 System.String System.Security.Cryptography.AsnEncodedData::EnhancedKeyUsageExtension(System.Boolean)
extern void AsnEncodedData_EnhancedKeyUsageExtension_mE04DC17ACCBF3850AFBA454D9937EC4713CC5058 ();
// 0x000000E3 System.String System.Security.Cryptography.AsnEncodedData::KeyUsageExtension(System.Boolean)
extern void AsnEncodedData_KeyUsageExtension_m4EE74EA5C4A3C0B72C50DEB22A537812997AF590 ();
// 0x000000E4 System.String System.Security.Cryptography.AsnEncodedData::SubjectKeyIdentifierExtension(System.Boolean)
extern void AsnEncodedData_SubjectKeyIdentifierExtension_m261D32E7AE226499BA8AD3FBE24FC0E71C9DEB76 ();
// 0x000000E5 System.String System.Security.Cryptography.AsnEncodedData::SubjectAltName(System.Boolean)
extern void AsnEncodedData_SubjectAltName_m94FE55170A872B3174D5C495A27AD09F3BACAF49 ();
// 0x000000E6 System.String System.Security.Cryptography.AsnEncodedData::NetscapeCertType(System.Boolean)
extern void AsnEncodedData_NetscapeCertType_m9191830C380BEC39DBE09065B2A4134193EA92D4 ();
// 0x000000E7 System.String System.Security.Cryptography.X509Certificates.X509Utils::FindOidInfo(System.UInt32,System.String,System.Security.Cryptography.OidGroup)
extern void X509Utils_FindOidInfo_mE43E0522988511319B8B9F69AF7D0A10B4AE8FA2 ();
// 0x000000E8 System.String System.Security.Cryptography.X509Certificates.X509Utils::FindOidInfoWithFallback(System.UInt32,System.String,System.Security.Cryptography.OidGroup)
extern void X509Utils_FindOidInfoWithFallback_m98443176879ABC2054619D4AA491FE086D406950 ();
// 0x000000E9 System.Security.Cryptography.AsnEncodedData System.Security.Cryptography.X509Certificates.PublicKey::get_EncodedKeyValue()
extern void PublicKey_get_EncodedKeyValue_m4BD0975B491E89FFE2A75C1ACDEB1DCCAF586D4F ();
// 0x000000EA System.Security.Cryptography.AsnEncodedData System.Security.Cryptography.X509Certificates.PublicKey::get_EncodedParameters()
extern void PublicKey_get_EncodedParameters_m629FF8D7E4EEDED96BC455B7B953DC5A46D26F4F ();
// 0x000000EB System.Security.Cryptography.Oid System.Security.Cryptography.X509Certificates.PublicKey::get_Oid()
extern void PublicKey_get_Oid_mB0AD65FDF84716726D5C7756E5B50CEAD1E4C2AE ();
// 0x000000EC System.Void System.Security.Cryptography.X509Certificates.PublicKey::.cctor()
extern void PublicKey__cctor_m9F739A93AE91AE86889835AAE256410F4DB808CC ();
// 0x000000ED System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor()
extern void X509BasicConstraintsExtension__ctor_m1D3F45762EB686500D2195886AD26FF84E5F4B3C ();
// 0x000000EE System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509BasicConstraintsExtension__ctor_mEED7AECEE911DF6CE692301F8F6F6B197DC05729 ();
// 0x000000EF System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor(System.Boolean,System.Boolean,System.Int32,System.Boolean)
extern void X509BasicConstraintsExtension__ctor_mD08FE3682F4B2EA23450C6609360F45656495780 ();
// 0x000000F0 System.Boolean System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_CertificateAuthority()
extern void X509BasicConstraintsExtension_get_CertificateAuthority_m282E5D9E7640A06AF2CE06A0FA374571F25BAB6F ();
// 0x000000F1 System.Boolean System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_HasPathLengthConstraint()
extern void X509BasicConstraintsExtension_get_HasPathLengthConstraint_m463A8B4DF4BEB46A9353309AA5EF3EAA2F7A4D42 ();
// 0x000000F2 System.Int32 System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_PathLengthConstraint()
extern void X509BasicConstraintsExtension_get_PathLengthConstraint_m93EF2B2BA6D6AD72DE59D98EB0E40DDD2AB3B49F ();
// 0x000000F3 System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509BasicConstraintsExtension_CopyFrom_mE64F232FB7DF702DCDB6692537B8F1010AA316DC ();
// 0x000000F4 System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::Decode(System.Byte[])
extern void X509BasicConstraintsExtension_Decode_m40A688DD3A933B24A3E9EFE505299F70AFF32E81 ();
// 0x000000F5 System.Byte[] System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::Encode()
extern void X509BasicConstraintsExtension_Encode_m04068558E7AF843C57A8BA9C39E251B7B37A1CDF ();
// 0x000000F6 System.String System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::ToString(System.Boolean)
extern void X509BasicConstraintsExtension_ToString_m75957B2B18A84645897676F0DAC473F022848336 ();
// 0x000000F7 System.Void System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509EnhancedKeyUsageExtension__ctor_mC91E46E79086AAFCD611FB3A223797D20BA9C1C2 ();
// 0x000000F8 System.Void System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509EnhancedKeyUsageExtension_CopyFrom_mC206A056C8C59401AA01F8C935DDE27D7E34D96A ();
// 0x000000F9 System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::Decode(System.Byte[])
extern void X509EnhancedKeyUsageExtension_Decode_m1865B86FE190237641C00804A058BF56F125183D ();
// 0x000000FA System.String System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::ToString(System.Boolean)
extern void X509EnhancedKeyUsageExtension_ToString_m99085514587961F4AB1CA3FB82E5223801475818 ();
// 0x000000FB System.Void System.Security.Cryptography.X509Certificates.X509Extension::.ctor()
extern void X509Extension__ctor_m75C6A788965E9C797F3D47DEFEC366EC2F69F384 ();
// 0x000000FC System.Boolean System.Security.Cryptography.X509Certificates.X509Extension::get_Critical()
extern void X509Extension_get_Critical_m8F4D4C2F0ECBE5CB4C9998CE3E56D5040E2EEBE2 ();
// 0x000000FD System.Void System.Security.Cryptography.X509Certificates.X509Extension::set_Critical(System.Boolean)
extern void X509Extension_set_Critical_mA2B424FF17DE53E01E586015DD1C742773B060B4 ();
// 0x000000FE System.Void System.Security.Cryptography.X509Certificates.X509Extension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509Extension_CopyFrom_m03B3EAD99E076090F01D26FF483E827397903A02 ();
// 0x000000FF System.String System.Security.Cryptography.X509Certificates.X509Extension::FormatUnkownData(System.Byte[])
extern void X509Extension_FormatUnkownData_mE5BAB7DB56CE215EB704A7E4E6866EBECA18F90A ();
// 0x00000100 System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor()
extern void X509KeyUsageExtension__ctor_mCCDDE2A55EF78832C8117C680FB264CE91893A99 ();
// 0x00000101 System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509KeyUsageExtension__ctor_mA9DDAD17EA38ABB83CD6CC9A353A0667A9EAC018 ();
// 0x00000102 System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags,System.Boolean)
extern void X509KeyUsageExtension__ctor_mBC544E9444992C7883638DB0B4607945F33E7426 ();
// 0x00000103 System.Security.Cryptography.X509Certificates.X509KeyUsageFlags System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::get_KeyUsages()
extern void X509KeyUsageExtension_get_KeyUsages_m9544DC0FAAD02C53D6C649E1831176CB54EFE505 ();
// 0x00000104 System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509KeyUsageExtension_CopyFrom_m8DA1FA691943CBD4B94E45096E83FC5EA9EEEA3F ();
// 0x00000105 System.Security.Cryptography.X509Certificates.X509KeyUsageFlags System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::GetValidFlags(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags)
extern void X509KeyUsageExtension_GetValidFlags_m7946BD756F14B17D707EE12E7D82878531D115EB ();
// 0x00000106 System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::Decode(System.Byte[])
extern void X509KeyUsageExtension_Decode_mDE97A425A199661D89FE252A75C8644D4280F1B2 ();
// 0x00000107 System.Byte[] System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::Encode()
extern void X509KeyUsageExtension_Encode_mBBF95E13B1FE1A0507FD692F770D6E98A68E3360 ();
// 0x00000108 System.String System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::ToString(System.Boolean)
extern void X509KeyUsageExtension_ToString_m4455C1B31C62530B930CFADE55DC0E77C60C7EFC ();
// 0x00000109 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor()
extern void X509SubjectKeyIdentifierExtension__ctor_mD586705C293A9C27B5B57BF9CF1D8EAD84864B29 ();
// 0x0000010A System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m45218EE7D32231FA6C44A40FEC2E5052162012D6 ();
// 0x0000010B System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Byte[],System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m182458124147FFEE402584E6415C2EA407B59C5B ();
// 0x0000010C System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.String,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m95DD08883D5E284C15820274737324063C4E4432 ();
// 0x0000010D System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.X509Certificates.PublicKey,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m98571FC543622A4BD3EA7788BB132348D9E0A3E3 ();
// 0x0000010E System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.X509Certificates.PublicKey,System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierHashAlgorithm,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_mF692F46CE97CB60AF86C1A74E709E8276B7D9AB1 ();
// 0x0000010F System.String System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::get_SubjectKeyIdentifier()
extern void X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m3480A14D8377B6C2D220F99D37AB8B13BEFE76FF ();
// 0x00000110 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509SubjectKeyIdentifierExtension_CopyFrom_m45E7EB4E976E4759046077C79FBC4A820C9A95EC ();
// 0x00000111 System.Byte System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHexChar(System.Char)
extern void X509SubjectKeyIdentifierExtension_FromHexChar_m7BDBE176CD85DCA3193FECF78D6CF15E349121BC ();
// 0x00000112 System.Byte System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHexChars(System.Char,System.Char)
extern void X509SubjectKeyIdentifierExtension_FromHexChars_mB2D3EBC7E627D44254A82E5628A2079C1DB24C38 ();
// 0x00000113 System.Byte[] System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHex(System.String)
extern void X509SubjectKeyIdentifierExtension_FromHex_m654E8BB1D2F9D8C878EF854D7933C6EA825F272B ();
// 0x00000114 System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::Decode(System.Byte[])
extern void X509SubjectKeyIdentifierExtension_Decode_m6EB136D7525F3DFB9FA93F8B3653D2F6FA3B72D1 ();
// 0x00000115 System.Byte[] System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::Encode()
extern void X509SubjectKeyIdentifierExtension_Encode_m11C84A3DCE621526C1FC282E214001D70937D6BD ();
// 0x00000116 System.String System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::ToString(System.Boolean)
extern void X509SubjectKeyIdentifierExtension_ToString_mB22086D5277B22093240BB9841D32D9008D26AFA ();
// 0x00000117 System.Void System.Net.EndPoint::.ctor()
extern void EndPoint__ctor_mFCD3A4BB994F59D40A3A94A6F1DEC4A731CC8776 ();
// 0x00000118 System.Void System.Net.IPAddress::.ctor(System.Int64)
extern void IPAddress__ctor_mFD0AF2F6A282D1158DF3C34EF2E63B73814E7748 ();
// 0x00000119 System.Void System.Net.IPAddress::.ctor(System.Byte[],System.Int64)
extern void IPAddress__ctor_m373D3930BEEA00EC628E98C5A13AE9BE2B2CEC84 ();
// 0x0000011A System.Void System.Net.IPAddress::.ctor(System.Int32)
extern void IPAddress__ctor_mCC321EEDA0750DA97447EB60529BCBCB4EA0249D ();
// 0x0000011B System.Int64 System.Net.IPAddress::get_ScopeId()
extern void IPAddress_get_ScopeId_m941461DEBDECCD858F8D3165F3CA366A318064D9 ();
// 0x0000011C System.String System.Net.IPAddress::ToString()
extern void IPAddress_ToString_m0CAEDDAF2A42F23EB1BE3BB353ABE741486710BF ();
// 0x0000011D System.Boolean System.Net.IPAddress::Equals(System.Object,System.Boolean)
extern void IPAddress_Equals_mADA54686760DE75E2C31B8651224FFEB019316D6 ();
// 0x0000011E System.Boolean System.Net.IPAddress::Equals(System.Object)
extern void IPAddress_Equals_mB38BAC1A15885A3181507BC9FD4E8F5765FA6678 ();
// 0x0000011F System.Int32 System.Net.IPAddress::GetHashCode()
extern void IPAddress_GetHashCode_m36CE850AFAAD382A29B7D72844989A3105565D7C ();
// 0x00000120 System.Void System.Net.IPAddress::.cctor()
extern void IPAddress__cctor_m4DF372012DF900E7BB489931296D0BFE4EBD4AEA ();
// 0x00000121 System.Void System.Net.IPv6AddressFormatter::.ctor(System.UInt16[],System.Int64)
extern void IPv6AddressFormatter__ctor_m94725668992E78AA0D75E1C072E8A567E9C34497_AdjustorThunk ();
// 0x00000122 System.UInt16 System.Net.IPv6AddressFormatter::SwapUShort(System.UInt16)
extern void IPv6AddressFormatter_SwapUShort_m6B7BA905E96BB0889C580EE25F3614C7A4A9164C ();
// 0x00000123 System.UInt32 System.Net.IPv6AddressFormatter::AsIPv4Int()
extern void IPv6AddressFormatter_AsIPv4Int_m94B06C695C45C85A90F95CAAF4430772EFC16C4F_AdjustorThunk ();
// 0x00000124 System.Boolean System.Net.IPv6AddressFormatter::IsIPv4Compatible()
extern void IPv6AddressFormatter_IsIPv4Compatible_mDC05432DB57ED01219A35BD1B712E589A527A5FC_AdjustorThunk ();
// 0x00000125 System.Boolean System.Net.IPv6AddressFormatter::IsIPv4Mapped()
extern void IPv6AddressFormatter_IsIPv4Mapped_m0BEBB1DE4A773028D3091D8321106BE92519A127_AdjustorThunk ();
// 0x00000126 System.String System.Net.IPv6AddressFormatter::ToString()
extern void IPv6AddressFormatter_ToString_mBBBF9A3ABB56F52589BD211DD827015066076C8F_AdjustorThunk ();
// 0x00000127 System.Int32 System.Net.Sockets.SocketException::WSAGetLastError_internal()
extern void SocketException_WSAGetLastError_internal_m18F05CF8D9CE2435225A4215ED757D8D98716FC3 ();
// 0x00000128 System.Void System.Net.Sockets.SocketException::.ctor()
extern void SocketException__ctor_mB16B95B2752EAD626C88A5230C1A8FEB7CF632CA ();
// 0x00000129 System.Void System.Net.Sockets.SocketException::.ctor(System.Net.Sockets.SocketError)
extern void SocketException__ctor_m2687C4EFA4D012280C5D19B89D8D01F97B6A2F1A ();
// 0x0000012A System.Void System.Net.Sockets.SocketException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void SocketException__ctor_m4C36461DF98089890FBF01908A4AAD301CABE071 ();
// 0x0000012B System.String System.Net.Sockets.SocketException::get_Message()
extern void SocketException_get_Message_m50B9DF4BB6F3B20F650E2F965B3DD654C8970378 ();
// 0x0000012C System.Void System.Collections.Generic.Stack`1::.ctor()
// 0x0000012D System.Int32 System.Collections.Generic.Stack`1::get_Count()
// 0x0000012E System.Void System.Collections.Generic.Stack`1::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
// 0x0000012F System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.Stack`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x00000130 System.Collections.IEnumerator System.Collections.Generic.Stack`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000131 T System.Collections.Generic.Stack`1::Peek()
// 0x00000132 T System.Collections.Generic.Stack`1::Pop()
// 0x00000133 System.Void System.Collections.Generic.Stack`1::Push(T)
// 0x00000134 System.Void System.Collections.Generic.Stack`1::ThrowForEmptyStack()
// 0x00000135 System.Void System.Collections.Generic.Stack`1_Enumerator::.ctor(System.Collections.Generic.Stack`1<T>)
// 0x00000136 System.Void System.Collections.Generic.Stack`1_Enumerator::Dispose()
// 0x00000137 System.Boolean System.Collections.Generic.Stack`1_Enumerator::MoveNext()
// 0x00000138 T System.Collections.Generic.Stack`1_Enumerator::get_Current()
// 0x00000139 System.Void System.Collections.Generic.Stack`1_Enumerator::ThrowEnumerationNotStartedOrEnded()
// 0x0000013A System.Object System.Collections.Generic.Stack`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x0000013B System.Void System.Collections.Generic.Stack`1_Enumerator::System.Collections.IEnumerator.Reset()
// 0x0000013C System.UInt32 <PrivateImplementationDetails>::ComputeStringHash(System.String)
extern void U3CPrivateImplementationDetailsU3E_ComputeStringHash_m7C7DB27BC4297A74A96AC53E1EDD3E7415DFB874 ();
// 0x0000013D System.Void System.Net.Configuration.BypassElementCollection::.ctor()
extern void BypassElementCollection__ctor_m867AF1FE6DBB2768AA199F45039C3E2641A9627A ();
// 0x0000013E System.Void System.Net.Configuration.ConnectionManagementElementCollection::.ctor()
extern void ConnectionManagementElementCollection__ctor_mA29AB3A62411F032C5EF86B16E7633A386000C7B ();
// 0x0000013F System.Void System.Net.Configuration.ConnectionManagementSection::.ctor()
extern void ConnectionManagementSection__ctor_m1112C1BE1A9466BBCDD5C2ED20E80CDE03B46CA4 ();
// 0x00000140 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ConnectionManagementSection::get_Properties()
extern void ConnectionManagementSection_get_Properties_m1737189D2D78E81728CFF1CCCEB99E1FFFEA3F19 ();
// 0x00000141 System.Void System.Net.Configuration.DefaultProxySection::.ctor()
extern void DefaultProxySection__ctor_m41EADE87065B61EDF32F67D2E62F04946886DAF6 ();
// 0x00000142 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.DefaultProxySection::get_Properties()
extern void DefaultProxySection_get_Properties_m6F70EC02D977EB16F86354188A72DC87A8959555 ();
// 0x00000143 System.Void System.Net.Configuration.DefaultProxySection::Reset(System.Configuration.ConfigurationElement)
extern void DefaultProxySection_Reset_m54AC9323047B1FB38795C9F466C1C01192F75276 ();
// 0x00000144 System.Void System.Net.Configuration.ProxyElement::.ctor()
extern void ProxyElement__ctor_mAFD852231DF0231726E41911409CB2725BE990AC ();
// 0x00000145 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ProxyElement::get_Properties()
extern void ProxyElement_get_Properties_m8A3EE4A3EEF2571DE4768730CEF4107331490377 ();
// 0x00000146 System.Void System.Net.Configuration.HttpWebRequestElement::.ctor()
extern void HttpWebRequestElement__ctor_mE3A4CA43FCC72E10B6C7B4920F429C028765E233 ();
// 0x00000147 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.HttpWebRequestElement::get_Properties()
extern void HttpWebRequestElement_get_Properties_m531EDF2F56823100C47A9EEE1575143E5EB5463C ();
// 0x00000148 System.Void System.Net.Configuration.Ipv6Element::.ctor()
extern void Ipv6Element__ctor_m3F7DF39E6E51517E1429BAE43FA782BF3AF17965 ();
// 0x00000149 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.Ipv6Element::get_Properties()
extern void Ipv6Element_get_Properties_m156008D7E5279C50DE4CEDB6D4D3CEDAF2ACF8DC ();
// 0x0000014A System.Void System.Net.Configuration.NetSectionGroup::.ctor()
extern void NetSectionGroup__ctor_m566D7C9466957BCE3B8FE2D0EA2582CC2F95F269 ();
// 0x0000014B System.Void System.Net.Configuration.SettingsSection::.ctor()
extern void SettingsSection__ctor_mC5F3D29EDC94D87B0B0542DE3702795441AC3005 ();
// 0x0000014C System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.SettingsSection::get_Properties()
extern void SettingsSection_get_Properties_m1ABB76DEC7441CFEDD4E7EDF99B8F5C258101254 ();
// 0x0000014D System.Void System.Net.Configuration.PerformanceCountersElement::.ctor()
extern void PerformanceCountersElement__ctor_m5A090222699B48BEB5FCC743198613FA8D081083 ();
// 0x0000014E System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.PerformanceCountersElement::get_Properties()
extern void PerformanceCountersElement_get_Properties_m3C7B73AC6E5F5E92426D7DC091A2ECE5CFCD9FD0 ();
// 0x0000014F System.Void System.Net.Configuration.ServicePointManagerElement::.ctor()
extern void ServicePointManagerElement__ctor_m61B031714F8498D467B5A0958EE62F73E0C58EB7 ();
// 0x00000150 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ServicePointManagerElement::get_Properties()
extern void ServicePointManagerElement_get_Properties_mC1C586246B4FE10AC90622A0CC6A5936D501B677 ();
// 0x00000151 System.Void System.Net.Configuration.SocketElement::.ctor()
extern void SocketElement__ctor_m428B7094399223FFB9A5B62BF9D8CEA18A00A4C3 ();
// 0x00000152 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.SocketElement::get_Properties()
extern void SocketElement_get_Properties_m9CF8E9B1A9B41B7EC24A4F91CE2E8ECBF317426A ();
// 0x00000153 System.Void System.Net.Configuration.WebProxyScriptElement::.ctor()
extern void WebProxyScriptElement__ctor_mC8AF875E80D96B18AA387148009AE1C630D83591 ();
// 0x00000154 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.WebProxyScriptElement::get_Properties()
extern void WebProxyScriptElement_get_Properties_m8AD25399F804B2D22BC8312102EBC28A0CAE6E26 ();
// 0x00000155 System.Void System.Net.Configuration.WebRequestModulesSection::.ctor()
extern void WebRequestModulesSection__ctor_m0CAB6F207E3B29D65AEA38A6AC191873E3000F02 ();
// 0x00000156 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.WebRequestModulesSection::get_Properties()
extern void WebRequestModulesSection_get_Properties_m909A3E4C4A61BFCC9D09F397D9314E5F74F3FE44 ();
// 0x00000157 System.Void System.Net.Configuration.WebRequestModuleElementCollection::.ctor()
extern void WebRequestModuleElementCollection__ctor_m8B880B0EAE7CEF1CB79CD264A9B6D62AB6A22961 ();
// 0x00000158 System.Void System.Diagnostics.DiagnosticsConfigurationHandler::.ctor()
extern void DiagnosticsConfigurationHandler__ctor_m185BC74B0225A3E16EEB4164923931B79AAA0CF0 ();
// 0x00000159 System.Object System.Diagnostics.DiagnosticsConfigurationHandler::Create(System.Object,System.Object,System.Xml.XmlNode)
extern void DiagnosticsConfigurationHandler_Create_mCC7EF5B43B6913E2429B37EC5923202EBB20AA96 ();
// 0x0000015A System.Void Unity.ThrowStub::ThrowNotSupportedException()
extern void ThrowStub_ThrowNotSupportedException_mF1DE187697F740D8C18B8966BBEB276878CD86FD ();
static Il2CppMethodPointer s_methodPointers[346] = 
{
	SR_GetString_m9548BD6DD52DFDB46372F211078AE57FA2401E39,
	SR_GetString_m9D671CBA422B18D15B8FF59B22DCCEB32E3D16E2,
	SR_GetString_m3FC710B15474A9B651DA02B303241B6D8B87E2A7,
	IriHelper_CheckIriUnicodeRange_mA9BAAD6D244ADEE8986FDC0DFB3DFDA90C093A6C,
	IriHelper_CheckIriUnicodeRange_m5ED29083C22062AEAB8B5787C9A27CFEEC397AD9,
	IriHelper_CheckIsReserved_m5C0A35BF0890852A3FC564618DB0836BBB6C0F1C,
	IriHelper_EscapeUnescapeIri_m6DE347247CE35DB4CE3129BEC2179F0095D69239,
	Uri_get_IsImplicitFile_m048350CB1E9AB92599F1557680A5D3B5FDE7C35D,
	Uri_get_IsUncOrDosPath_mE372CA996BE5B29DD531D7C6DD1809E17441005E,
	Uri_get_IsDosPath_m89CA4E32381C529502E91872BC89BD18F5419D08,
	Uri_get_HostType_mBB4EE8652EA19E2FB8C696302D5EBE82F358EC90,
	Uri_get_Syntax_m3DB6A5D9E6FC3E0D0A63EA8A4527AF4106F9BD78,
	Uri_get_IsNotAbsoluteUri_mF9706123EB027C6E9AB263B98CE58CF319A22919,
	Uri_IriParsingStatic_m39FC9677B4B9EFBADF814F2EEA58280F35A1D3E5,
	Uri_get_AllowIdn_mF1833CB700E04D746D75428948BEBC70536E1941,
	Uri_AllowIdnStatic_mFABD19611F334DF87EC3FF2B9A1FA061CAE3A5C5,
	Uri_IsIntranet_mE98CA41B60FE0D4970737C8B7C81E5C63BFC07E1,
	Uri_get_UserDrivenParsing_mFF27964894B5C0432C37E425F319D6C915BCDC39,
	Uri_SetUserDrivenParsing_m0368CB47B9E9C35CB49B3F02DBE8DFED8756226B,
	Uri_get_SecuredPathIndex_mC59A2366D6F3667017F677351C4350C9541905AA,
	Uri_NotAny_mC5DC04B72B13D2997B055B9E41FCFEEC1CE5263D,
	Uri_InFact_m4CE890C86FA34154A044516D2F3C9463389220D7,
	Uri_StaticNotAny_mC07A1201FBE032238FCFA96E9FB5D60AEDACCC5A,
	Uri_StaticInFact_m77BB2AE094534AFD7B9F68683C2A4356A75E39B8,
	Uri_EnsureUriInfo_m4B46DF8611FA6D20D497D12D00544CFB466DCFA7,
	Uri_EnsureParseRemaining_m33815B5767FAFADB762F7E39364E6432340F210B,
	Uri_EnsureHostString_m4BD63AA5A88CA09572A8A7CF3B2EDDE17EF9C720,
	Uri__ctor_mBA69907A1D799CD12ED44B611985B25FE4C626A2,
	Uri_GetException_m2E833A8358C84BCF0397341160FADB1164290164,
	Uri__ctor_m020E8051B3C0C9E60D8A868CBA0774B3FFB7C3FF,
	Uri_System_Runtime_Serialization_ISerializable_GetObjectData_mD4773E59427820077E86F2B298DA1386028DAC9C,
	Uri_GetObjectData_mC8CCD55C21CB624E369258E27A89F363F8271E68,
	Uri_StaticIsFile_mD270A5F6C8B59AAF6256B4565ABE5917ABA545E3,
	Uri_get_InitializeLock_m45D6A11D14958E716715351E52207DCA808F00EE,
	Uri_InitializeUriConfig_m1B2F98DF0BB1A48FEB328E9D8BF3C23B32196FE2,
	Uri_get_Port_m4E64AB9B50CCC50E7B1F139D7AF1403FAF97147C,
	Uri_get_OriginalStringSwitched_m79E1C9F1C4E0ACCC85BB68841C167DDEA15CC72D,
	Uri_get_OriginalString_m56099E46276F0A52524347F1F46A2F88E948504F,
	Uri_get_IsAbsoluteUri_m8C189085F1C675DBC3148AA70C38074EC075D722,
	Uri_IsGenDelim_m376CCA5D00D019A69FD746C57D236A54EB9D3CF3,
	Uri_IsHexDigit_m3B2881FA99F0B2197F8017E70C3AE6EBF9849836,
	Uri_FromHex_m9EAC76A5DBFED86532FF7E1BBD809176337A227B,
	Uri_GetHashCode_m06066B9059649A690C5B4DE58D32DF227933F515,
	Uri_ToString_mB76863E11134B9635149E8E5F59AB75A74A760E2,
	Uri_op_Inequality_m07015206F59460E87CDE2A8D303D5712E30A7F6B,
	Uri_Equals_m432A30F5E72A0F2B729AC051892BF9E1F4D26629,
	Uri_ParseScheme_m61CAE16F1EC76725E5E0B23B09577F91BB223884,
	Uri_ParseMinimal_m35FCFE52F12315DA60733B807E7C0AB408C0A9CF,
	Uri_PrivateParseMinimal_mE1DA461DDA053787906BBEC2BC2B3046B1B329F0,
	Uri_PrivateParseMinimalIri_m29F0CA367080586448C648332F59BED0096AB2D0,
	Uri_CreateUriInfo_mC112D6E7002CA014AB6BEA878A66ECC46340FAAF,
	Uri_CreateHostString_m6FEC48641D3786D73B50D5DC792804C9A4D70C54,
	Uri_CreateHostStringHelper_m6C5EEA8BD2CDBCDD8A63FB74D3B801329EDE7BDD,
	Uri_GetHostViaCustomSyntax_mD591A4A615803E70A03D7C75E7C114E4E460AED3,
	Uri_GetParts_mF5840DC010E6D420EB5A0722320EDAAEA2D0269F,
	Uri_GetEscapedParts_m745615124808CB89A18D499988F4425F678938C4,
	Uri_GetUnescapedParts_m051A75B5D2DDAE55F107457CA468EE9A2563FED3,
	Uri_ReCreateParts_mF50263ABC7D750E939B57BF61FA48A8762144FD7,
	Uri_GetUriPartsFromUserString_m95A7794F28625B6AFD514C08765C27CAAE4BD1B6,
	Uri_ParseRemaining_mBAE0F9850CD84965B3793B17444C677D77D58774,
	Uri_ParseSchemeCheckImplicitFile_m92A658AE6C04E038058AD8E9581A41B06B6D6243,
	Uri_CheckKnownSchemes_mCA95AE251E7C9208570543B446385BCF2C727E8D,
	Uri_CheckSchemeSyntax_m1181D9BEA35D9D22852FD2FE815CABB267BA5A8F,
	Uri_CheckAuthorityHelper_m5046CE781115A54CAE3ACD2C03987F526A761387,
	Uri_CheckAuthorityHelperHandleDnsIri_m366E36029D4C9A00C0F216055B15F5E4805AED28,
	Uri_CheckAuthorityHelperHandleAnyHostIri_m76FEA31E3FEDF3D1614987C6484ECF15022AE9D8,
	Uri_FindEndOfComponent_mF276ABD008291C1FDC4B433A2F274058D06D8A6B,
	Uri_FindEndOfComponent_mDCDF860C405E9F31F7CFE9AFFE7C096812697AEF,
	Uri_CheckCanonical_mED3910E55213D1DFEAA5B33079E3A89D369B10B6,
	Uri_GetCanonicalPath_mDE02BFA56EDD09479DDB2A5A50F6DF5210CA73F2,
	Uri_UnescapeOnly_mB8F87981CDD4CFBFCD97EE668FF281CE26453F21,
	Uri_Compress_m02224082A9665F07D35AB6EB6E3198642F9E7BCF,
	Uri_CalculateCaseInsensitiveHashCode_m634FFDF8FCD81DECCB87161B153D1093C0A6FCE4,
	Uri_IsLWS_m7A9F3B969CCEE56B9F98E40F1903C737DA7DF0D6,
	Uri_IsAsciiLetter_m93435A20DF4DEE153B87B26D07B9963F1BF4F373,
	Uri_IsAsciiLetterOrDigit_mEBA81E735141504B5804F0B3C94EC39B24AF8661,
	Uri_IsBidiControlCharacter_mB14EA5816A434B7CE382EB9ACBD1432916EC341D,
	Uri_StripBidiControlCharacter_m49D782826401F99D943C1AD76A75125879FF332F,
	Uri_CreateThis_mCB3DC849A426498E9CCD249850CBC69C9D67D864,
	Uri_InitializeUri_m5D99BD8533F3FAAD479B1193505B5B19B8C2F2DE,
	Uri_CheckForConfigLoad_m13002EFBBFD437183ED0A7FCBE5681C510996B0F,
	Uri_CheckForUnicode_m78E4938E82EE352BD5D8493AE0314224BC2543CD,
	Uri_CheckForEscapedUnreserved_mFE708A44EC74C7E773B96B82CD9A5DF25EF97D4A,
	Uri_TryCreate_mEEB6736FEDAF52AAE36ACC1EA1EC8CEBB7C52DAB,
	Uri_GetComponents_m0346CA8037531DE1FC630775E0BD1F5D1E7920B6,
	Uri_UnescapeDataString_mE1F40FC5CA3FF03DEE9EB01E3D8BD502D36A284D,
	Uri_EscapeUnescapeIri_mDE5E4BAE74E2C2373AD186732FEE7AD6E0EA7180,
	Uri__ctor_m4605489523A7A973459720C1BBE4039FD10557CD,
	Uri_CreateHelper_m024137C47351CA9959E4AC66F9443AEEE87D89C0,
	Uri_GetRelativeSerializationString_m5D0CD02E255BB96532F056BB382CF7D74D62BE58,
	Uri_GetComponentsHelper_m28B0D80FD94A40685C0F70652AB26755C457B2D3,
	Uri__cctor_m2B8179039C09C64936CF8262E3EF4A7E7C2F90F2,
	UriInfo__ctor_m24EFE7B4E03C9FFB8B797770D626680947C87D98,
	MoreInfo__ctor_mFE29F028646C12EDCAF7F0F78F9A85D52C10B83C,
	UriFormatException__ctor_mBA5F8C423C09F600B1AF895521C892EA356CA424,
	UriFormatException__ctor_mE1D46962CC168EB07B59D1265F5734A8F587567D,
	UriFormatException__ctor_mE7F5B073E9F9DB5F22536C54959BEB0D1E7DA1D5,
	UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_mED4C06AC35B7F94955ECC0D8F00383888C1127DC,
	UriHelper_EscapeString_mF0077A016F05127923308DF7E7E99BD7B9837E8B,
	UriHelper_EnsureDestinationSize_m64F4907D0411AAAD1C05E0AD0D2EB120DCBA9217,
	UriHelper_UnescapeString_mC172F713349E3D22985A92BC4F5B51D0BCEE61AF,
	UriHelper_UnescapeString_mD4815AEAF34E25D31AA4BB4A76B88055F0A49E89,
	UriHelper_MatchUTF8Sequence_m4835D9BB77C2701643B14D6FFD3D7057F8C9007F,
	UriHelper_EscapeAsciiChar_mFD7DE796BD53CBD2B1E73080FE0346D37F358902,
	UriHelper_EscapedAscii_m06D556717795E649EBBB30E4CBCF3D221C1FEB78,
	UriHelper_IsNotSafeForUnescape_m1D0461E7C5A3CFBD7A2A7F7322B66BC68CCE741D,
	UriHelper_IsReservedUnreservedOrHash_m3D7256DABA7F540F8D379FC1D1C54F1C63E46059,
	UriHelper_IsUnreserved_mAADC7DCEEA864AFB49311696ABBDD76811FAAE48,
	UriHelper_Is3986Unreserved_m3799F2ADA8C63DDB4995F82B974C8EC1DEEBA76A,
	UriHelper__cctor_m9537B8AAAA1D6EF77D29A179EC79F5511C662F27,
	UriParser_get_SchemeName_mFC9EFD71512A64E640866792CCB7DAC5187DE9F1,
	UriParser_get_DefaultPort_m050510870CCD4DD08DF7E98E2AF3D616446AD99D,
	UriParser_OnNewUri_m7D55337A7A9B6B67FB0AD7CA96F472751EF5A897,
	UriParser_InitializeAndValidate_m3E31D86FEE445E313BB7141F760626301767A0E0,
	UriParser_GetComponents_m8A226F43638FA7CD135A651CDE3D4E475E8FC181,
	UriParser_get_ShouldUseLegacyV2Quirks_mD4C8DF67677ACCCC3B5E026099ECC0BDA24D96DD,
	UriParser__cctor_m00C2855D5C8C07790C5627BBB90AC84A7E8B6BC2,
	UriParser_get_Flags_mBCF4C3E94892F00B6E8856BFED1B650FB6A0C039,
	UriParser_NotAny_mC998A35DC290F35FFAFFB6A8B66C7B881F2559D3,
	UriParser_InFact_mDD42FA932B6830D99AA04C2AE7875BA5067C86F3,
	UriParser_IsAllSet_m74BEC412DC8AF3B1A33E11964EBB3164D9D8C77E,
	UriParser_IsFullMatch_m7B5F47A62FA721E550C5439FAA4C6AFAC34EB23E,
	UriParser__ctor_mAF168F2B88BC5301B722C1BAAD45E381FBA22E3D,
	UriParser_FindOrFetchAsUnknownV1Syntax_m3A57CA15FE27DC7982F186E8321B810B56EBD9AD,
	UriParser_get_IsSimple_mDDB03A5F6EEE6E92926A386655E5BBD553719B9C,
	UriParser_InternalOnNewUri_m7D55F5CD59A3B9BF57BC68F715A27CC1A44566CA,
	UriParser_InternalValidate_mF2FEB0E76E48B621EB2058FBE7DCC6A42A1681E2,
	UriParser_InternalGetComponents_mFD4B211C71E0506AE4E4E99D92ECAF1780CE4674,
	BuiltInUriParser__ctor_m66250DC53CE01410149D46279D0B413FC1C5CA1C,
	DomainNameHelper_ParseCanonicalName_mFE738FD1237E2D9D9A1B27BA73F58B1689D451E4,
	DomainNameHelper_IsValid_mE9672A824F71E32116358C5FA029789855A4B461,
	DomainNameHelper_IsValidByIri_m13E2A6D9EBD42326C096F2423DBB0014763D47BF,
	DomainNameHelper_IdnEquivalent_m439593BAF7C6C801F577E7C27B0C4FBB1772E49F,
	DomainNameHelper_IdnEquivalent_m459BFF3040F8E6BFE1CE1C6432A1343A2ECF2F57,
	DomainNameHelper_IsIdnAce_m2231C778C4CCE141ACDC412737642CC365307445,
	DomainNameHelper_IsIdnAce_m9193B7D824FC6965820FCE980FEE3E0B40EA94B8,
	DomainNameHelper_UnicodeEquivalent_mA80E5FF3AD6AFBB9FC257ED1C4F0D31C8F0EFEC3,
	DomainNameHelper_UnicodeEquivalent_mD5A7A659B82F1FBF7ABF30009117CFBF8BC4D55F,
	DomainNameHelper_IsASCIILetterOrDigit_mD3B0B9BD4573FADEF6AC7330A5EC58C220455F01,
	DomainNameHelper_IsValidDomainLabelCharacter_mF6DEB20D9D03A8728B1C58006C40D6603B7D61D1,
	IPv4AddressHelper_ParseCanonicalName_m2A8C35045CE02D6FC2C4251F239D1C0074E0E813,
	IPv4AddressHelper_ParseHostNumber_m798FB6828971F70775D1125565A1D1025C897F14,
	IPv4AddressHelper_IsValid_mD96D91E0F3830414F4601A4521E71DE832A45843,
	IPv4AddressHelper_IsValidCanonical_mC27E31F1F043D68BC52719892D34EDDC7851B120,
	IPv4AddressHelper_ParseNonCanonical_mDCD1CD7FB85C4FFBF3070B1435A0D632C1A7B97E,
	IPv4AddressHelper_Parse_m08110623FAC14806376148D7C16AB95A428EA6CF,
	IPv4AddressHelper_ParseCanonical_m9D4552558C934E373D188DDA0BC1D1DEF5A62C33,
	IPv6AddressHelper_ParseCanonicalName_m3944530A7B686031653F97824EF712424E0BEE14,
	IPv6AddressHelper_CreateCanonicalName_m0B1C201DFADBEB58869E0BE8BFA967EEE64B096A,
	IPv6AddressHelper_FindCompressionRange_mE70B131DDA05D3059325246A5AB7F6029B6EF6BD,
	IPv6AddressHelper_ShouldHaveIpv4Embedded_m262634E9099141536C00213C1CFC123665A641DE,
	IPv6AddressHelper_InternalIsValid_m3BD7E7524455146D4464037DA3B65530E547AB7A,
	IPv6AddressHelper_IsValid_m2383F1A867665B04A4F2B8D82FF2B62BE51C2289,
	IPv6AddressHelper_Parse_m36CE2F56465C4F9F7791E80E954C7C0ECBD16DFB,
	UncNameHelper_ParseCanonicalName_mCBE64015FD1B6B4829CEAA89625C1D44E280E37E,
	UncNameHelper_IsValid_m4055361D79684EE7B098C055B2E9068EE06F1EF6,
	IOAsyncCallback__ctor_m1010BF5234B0ECC2FEB54105BA15B313633C1985,
	IOAsyncCallback_Invoke_mB95F7E7F0E8326CE5364A30F42FC1073B0AB2D8B,
	IOAsyncCallback_BeginInvoke_mB8CACF8990B91DF4A695E597CEBE4BA09354C32C,
	IOAsyncCallback_EndInvoke_m397237D5497A9029CC3FACE692D11BDC1558A727,
	UriTypeConverter__ctor_m1CAEEF1C615B28212B83C76D892938E0A77D3A64,
	Stopwatch_GetTimestamp_m7A4B2D144D880343DB783326F36F6996C1D1A1CA,
	Stopwatch__ctor_mA301E9A9D03758CBE09171E0C140CCD06BC9F860,
	Stopwatch_get_Elapsed_m6735B32BFB466FC4F52112AC3493D37404D184BB,
	Stopwatch_get_ElapsedMilliseconds_mE39424FB61C885BCFCC4B583C58A8630C3AD8177,
	Stopwatch_get_ElapsedTicks_mABB4710231090C75F057E90A29C71C553077A901,
	Stopwatch_Start_mF61332B96D7753ADA18366A29E22E2A92E25739A,
	Stopwatch__cctor_m137C0B2E7182FAEA6E030CD1EDC909E5A3F7A064,
	ArrayConverter__ctor_m831D145364A55A155BC896935367961A476D53B7,
	BooleanConverter__ctor_m8293C29BCB7B90516FFE978C6295C0378C1BFEE4,
	CollectionConverter__ctor_m86DBE477F4462418329C5CFB45C86A9420F852E7,
	DecimalConverter__ctor_mB015B3871CF834D0C5D8290C9FD15509249921E7,
	DoubleConverter__ctor_m419F1E782FFBC765D22792D76E56D54FC94E6AEB,
	EditorBrowsableAttribute__ctor_mACDE45DF0DCAA6E923120D6AEC45422AEF958C2E,
	EditorBrowsableAttribute_Equals_m6F5EF9CC298CBDC862CBCA5187379A79635726FA,
	EditorBrowsableAttribute_GetHashCode_m74229847CE44E771F282E2E73FFC4DE55771A1B6,
	EnumConverter__ctor_mBA8B2E210D061A3CF86950F6D797E911A2E3C774,
	Int16Converter__ctor_mD4D022096E6FB9FFDB84D879E31177A892DD072D,
	Int32Converter__ctor_m1CD79AE5880FDE2EC91F1D67E567AAA3618D19B9,
	Int64Converter__ctor_mE4DC71A97EF110B854F22A48AB0F0D3792B53A74,
	SingleConverter__ctor_m8EA7D412C3EE9A9522E7592774DD46EBC6118AA8,
	StringConverter__ctor_m2718AC00691AF4A3AF8A8D64896BE3B5D58658B2,
	TimeSpanConverter__ctor_m28E7294174F979EF86FEF9511474B0AB9431217B,
	TypeConverter__ctor_m7F8A006E775CCB83A8ACB042B296E48B0AE501CD,
	TypeConverterAttribute__ctor_mD0795A29B6FD59978CAAC6DAF3AC7EC564C519A5,
	TypeConverterAttribute__ctor_m52D4E66A914F1A04F2F10A7131A701670225D41C,
	TypeConverterAttribute_get_ConverterTypeName_m883941C77E14FC5B4A3E32DD8F59F11739D5D6D8,
	TypeConverterAttribute_Equals_mDA74DFC28CC7ABC315407EDD1AAC14531C5F6AC4,
	TypeConverterAttribute_GetHashCode_m35874D49724DA3F72C6C2575FD595A711A659DAA,
	TypeConverterAttribute__cctor_mB1A775F56A5933A17CF349BD466B0CCE66B1078A,
	Win32Exception__ctor_mC03E215A1695ED64DDC50F4BE9F59966974DF759,
	Win32Exception__ctor_m2BEA755F6AA536ADDDF07D83BD8297F02584F714,
	Win32Exception__ctor_m94A043EE26097BBFE0ED22FD4EBEA357F142EFE6,
	Win32Exception__ctor_mC7ADDE9D2FEE4E17432F63C24EF1D872380094DB,
	Win32Exception_GetObjectData_m7CD0D7A0806E4A9D8E78ADCBC616700379AB79E8,
	Win32Exception_GetErrorMessage_m6085687D868718B45289CB6AF6EDCB7F89D7350D,
	Win32Exception_InitializeErrorMessages_m4FE6F56C1C2CCB3F6468F0F9F5AD6E1B08673438,
	Win32Exception__cctor_m800CD9D0B3E3253B79A19B6646A7D28B29C3FC52,
	BaseNumberConverter__ctor_mD78E1C7E1F8A977BC7AD33DB0C1E5E32C60E8E83,
	Oid__ctor_m45F49EB1ABFD4F3EB0FC9729C76FF83995752743,
	Oid__ctor_m67437A59D4E75ABF6E40D503F57F81199546E5EC,
	Oid__ctor_m0656E1FC1A7E7BBF694A568DDDF8BE4AFA544985,
	Oid__ctor_mA7AFE14DF30B47447BFFC9E41B37B8DB46C9D079,
	Oid_get_Value_mFE18BDFF095DD5A6643F4FEC3E57846716F37F05,
	Oid_set_Value_m304CEF248379566701402100FA015EAC640C033F,
	OidCollection__ctor_m99B93BB5B35BF7A395CFB7F8B155DFA8DD734800,
	OidCollection_Add_m1FF686421A22A86F8296259D99DA38E02B8BBF5C,
	OidCollection_get_Item_mB37F923F4714BFE0DF44E8EE4A1A5EA1F3EBB1D9,
	OidCollection_get_Count_m6AC0709CDD68451F4CAC942CE94A5A97F3C294B2,
	OidCollection_System_Collections_IEnumerable_GetEnumerator_m3FD3A96DFF93BD88A3B28E35A4DEF57AF25ECB30,
	OidCollection_System_Collections_ICollection_CopyTo_mE508CB1FD9E56CCFE5A4BDD5251D815BF78AC5A9,
	OidEnumerator__ctor_mCA4FBC8408E2B04FD0A524E256E284E8A44E0797,
	OidEnumerator_System_Collections_IEnumerator_get_Current_mF11B1F886842EA79EDB215BD5106D0C4C65EBE53,
	OidEnumerator_MoveNext_m073D94D5D3254D53DF53429ACAD0AA9BD682221D,
	OidEnumerator_Reset_m5006C3B1283711E2BDDEA6C25FDF93BBB900195E,
	CAPI_CryptFindOIDInfoNameFromKey_mA2FD2F391E133E586BC8B827DD916613B590E698,
	CAPI_CryptFindOIDInfoKeyFromName_m7809CD491D913D58FA1B996B835A0A91C413E9DB,
	AsnEncodedData__ctor_mED24E9D1F11942741819652302C0531D18C39BE6,
	AsnEncodedData_set_Oid_m91E38503AAFD8E6FD98970D94FD43E7A738242A6,
	AsnEncodedData_get_RawData_mB9F8281A96011161C67EB3A9208E26C423B187EC,
	AsnEncodedData_set_RawData_mD7FE2383373A6AF578A4983999D677B58BD6B4EC,
	AsnEncodedData_CopyFrom_m3937C7ACC425960B8E48B7D2EB50E9417A7CD4B7,
	AsnEncodedData_ToString_m502785F2F8B4D1EBDF5CEE612FD8D0C2044390D7,
	AsnEncodedData_Default_mEEA94BA253ED1B8A719466A8152A5333E0E3FF07,
	AsnEncodedData_BasicConstraintsExtension_m64D690A2456E16AF39F6F0784CE74BC9533BB182,
	AsnEncodedData_EnhancedKeyUsageExtension_mE04DC17ACCBF3850AFBA454D9937EC4713CC5058,
	AsnEncodedData_KeyUsageExtension_m4EE74EA5C4A3C0B72C50DEB22A537812997AF590,
	AsnEncodedData_SubjectKeyIdentifierExtension_m261D32E7AE226499BA8AD3FBE24FC0E71C9DEB76,
	AsnEncodedData_SubjectAltName_m94FE55170A872B3174D5C495A27AD09F3BACAF49,
	AsnEncodedData_NetscapeCertType_m9191830C380BEC39DBE09065B2A4134193EA92D4,
	X509Utils_FindOidInfo_mE43E0522988511319B8B9F69AF7D0A10B4AE8FA2,
	X509Utils_FindOidInfoWithFallback_m98443176879ABC2054619D4AA491FE086D406950,
	PublicKey_get_EncodedKeyValue_m4BD0975B491E89FFE2A75C1ACDEB1DCCAF586D4F,
	PublicKey_get_EncodedParameters_m629FF8D7E4EEDED96BC455B7B953DC5A46D26F4F,
	PublicKey_get_Oid_mB0AD65FDF84716726D5C7756E5B50CEAD1E4C2AE,
	PublicKey__cctor_m9F739A93AE91AE86889835AAE256410F4DB808CC,
	X509BasicConstraintsExtension__ctor_m1D3F45762EB686500D2195886AD26FF84E5F4B3C,
	X509BasicConstraintsExtension__ctor_mEED7AECEE911DF6CE692301F8F6F6B197DC05729,
	X509BasicConstraintsExtension__ctor_mD08FE3682F4B2EA23450C6609360F45656495780,
	X509BasicConstraintsExtension_get_CertificateAuthority_m282E5D9E7640A06AF2CE06A0FA374571F25BAB6F,
	X509BasicConstraintsExtension_get_HasPathLengthConstraint_m463A8B4DF4BEB46A9353309AA5EF3EAA2F7A4D42,
	X509BasicConstraintsExtension_get_PathLengthConstraint_m93EF2B2BA6D6AD72DE59D98EB0E40DDD2AB3B49F,
	X509BasicConstraintsExtension_CopyFrom_mE64F232FB7DF702DCDB6692537B8F1010AA316DC,
	X509BasicConstraintsExtension_Decode_m40A688DD3A933B24A3E9EFE505299F70AFF32E81,
	X509BasicConstraintsExtension_Encode_m04068558E7AF843C57A8BA9C39E251B7B37A1CDF,
	X509BasicConstraintsExtension_ToString_m75957B2B18A84645897676F0DAC473F022848336,
	X509EnhancedKeyUsageExtension__ctor_mC91E46E79086AAFCD611FB3A223797D20BA9C1C2,
	X509EnhancedKeyUsageExtension_CopyFrom_mC206A056C8C59401AA01F8C935DDE27D7E34D96A,
	X509EnhancedKeyUsageExtension_Decode_m1865B86FE190237641C00804A058BF56F125183D,
	X509EnhancedKeyUsageExtension_ToString_m99085514587961F4AB1CA3FB82E5223801475818,
	X509Extension__ctor_m75C6A788965E9C797F3D47DEFEC366EC2F69F384,
	X509Extension_get_Critical_m8F4D4C2F0ECBE5CB4C9998CE3E56D5040E2EEBE2,
	X509Extension_set_Critical_mA2B424FF17DE53E01E586015DD1C742773B060B4,
	X509Extension_CopyFrom_m03B3EAD99E076090F01D26FF483E827397903A02,
	X509Extension_FormatUnkownData_mE5BAB7DB56CE215EB704A7E4E6866EBECA18F90A,
	X509KeyUsageExtension__ctor_mCCDDE2A55EF78832C8117C680FB264CE91893A99,
	X509KeyUsageExtension__ctor_mA9DDAD17EA38ABB83CD6CC9A353A0667A9EAC018,
	X509KeyUsageExtension__ctor_mBC544E9444992C7883638DB0B4607945F33E7426,
	X509KeyUsageExtension_get_KeyUsages_m9544DC0FAAD02C53D6C649E1831176CB54EFE505,
	X509KeyUsageExtension_CopyFrom_m8DA1FA691943CBD4B94E45096E83FC5EA9EEEA3F,
	X509KeyUsageExtension_GetValidFlags_m7946BD756F14B17D707EE12E7D82878531D115EB,
	X509KeyUsageExtension_Decode_mDE97A425A199661D89FE252A75C8644D4280F1B2,
	X509KeyUsageExtension_Encode_mBBF95E13B1FE1A0507FD692F770D6E98A68E3360,
	X509KeyUsageExtension_ToString_m4455C1B31C62530B930CFADE55DC0E77C60C7EFC,
	X509SubjectKeyIdentifierExtension__ctor_mD586705C293A9C27B5B57BF9CF1D8EAD84864B29,
	X509SubjectKeyIdentifierExtension__ctor_m45218EE7D32231FA6C44A40FEC2E5052162012D6,
	X509SubjectKeyIdentifierExtension__ctor_m182458124147FFEE402584E6415C2EA407B59C5B,
	X509SubjectKeyIdentifierExtension__ctor_m95DD08883D5E284C15820274737324063C4E4432,
	X509SubjectKeyIdentifierExtension__ctor_m98571FC543622A4BD3EA7788BB132348D9E0A3E3,
	X509SubjectKeyIdentifierExtension__ctor_mF692F46CE97CB60AF86C1A74E709E8276B7D9AB1,
	X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m3480A14D8377B6C2D220F99D37AB8B13BEFE76FF,
	X509SubjectKeyIdentifierExtension_CopyFrom_m45E7EB4E976E4759046077C79FBC4A820C9A95EC,
	X509SubjectKeyIdentifierExtension_FromHexChar_m7BDBE176CD85DCA3193FECF78D6CF15E349121BC,
	X509SubjectKeyIdentifierExtension_FromHexChars_mB2D3EBC7E627D44254A82E5628A2079C1DB24C38,
	X509SubjectKeyIdentifierExtension_FromHex_m654E8BB1D2F9D8C878EF854D7933C6EA825F272B,
	X509SubjectKeyIdentifierExtension_Decode_m6EB136D7525F3DFB9FA93F8B3653D2F6FA3B72D1,
	X509SubjectKeyIdentifierExtension_Encode_m11C84A3DCE621526C1FC282E214001D70937D6BD,
	X509SubjectKeyIdentifierExtension_ToString_mB22086D5277B22093240BB9841D32D9008D26AFA,
	EndPoint__ctor_mFCD3A4BB994F59D40A3A94A6F1DEC4A731CC8776,
	IPAddress__ctor_mFD0AF2F6A282D1158DF3C34EF2E63B73814E7748,
	IPAddress__ctor_m373D3930BEEA00EC628E98C5A13AE9BE2B2CEC84,
	IPAddress__ctor_mCC321EEDA0750DA97447EB60529BCBCB4EA0249D,
	IPAddress_get_ScopeId_m941461DEBDECCD858F8D3165F3CA366A318064D9,
	IPAddress_ToString_m0CAEDDAF2A42F23EB1BE3BB353ABE741486710BF,
	IPAddress_Equals_mADA54686760DE75E2C31B8651224FFEB019316D6,
	IPAddress_Equals_mB38BAC1A15885A3181507BC9FD4E8F5765FA6678,
	IPAddress_GetHashCode_m36CE850AFAAD382A29B7D72844989A3105565D7C,
	IPAddress__cctor_m4DF372012DF900E7BB489931296D0BFE4EBD4AEA,
	IPv6AddressFormatter__ctor_m94725668992E78AA0D75E1C072E8A567E9C34497_AdjustorThunk,
	IPv6AddressFormatter_SwapUShort_m6B7BA905E96BB0889C580EE25F3614C7A4A9164C,
	IPv6AddressFormatter_AsIPv4Int_m94B06C695C45C85A90F95CAAF4430772EFC16C4F_AdjustorThunk,
	IPv6AddressFormatter_IsIPv4Compatible_mDC05432DB57ED01219A35BD1B712E589A527A5FC_AdjustorThunk,
	IPv6AddressFormatter_IsIPv4Mapped_m0BEBB1DE4A773028D3091D8321106BE92519A127_AdjustorThunk,
	IPv6AddressFormatter_ToString_mBBBF9A3ABB56F52589BD211DD827015066076C8F_AdjustorThunk,
	SocketException_WSAGetLastError_internal_m18F05CF8D9CE2435225A4215ED757D8D98716FC3,
	SocketException__ctor_mB16B95B2752EAD626C88A5230C1A8FEB7CF632CA,
	SocketException__ctor_m2687C4EFA4D012280C5D19B89D8D01F97B6A2F1A,
	SocketException__ctor_m4C36461DF98089890FBF01908A4AAD301CABE071,
	SocketException_get_Message_m50B9DF4BB6F3B20F650E2F965B3DD654C8970378,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CPrivateImplementationDetailsU3E_ComputeStringHash_m7C7DB27BC4297A74A96AC53E1EDD3E7415DFB874,
	BypassElementCollection__ctor_m867AF1FE6DBB2768AA199F45039C3E2641A9627A,
	ConnectionManagementElementCollection__ctor_mA29AB3A62411F032C5EF86B16E7633A386000C7B,
	ConnectionManagementSection__ctor_m1112C1BE1A9466BBCDD5C2ED20E80CDE03B46CA4,
	ConnectionManagementSection_get_Properties_m1737189D2D78E81728CFF1CCCEB99E1FFFEA3F19,
	DefaultProxySection__ctor_m41EADE87065B61EDF32F67D2E62F04946886DAF6,
	DefaultProxySection_get_Properties_m6F70EC02D977EB16F86354188A72DC87A8959555,
	DefaultProxySection_Reset_m54AC9323047B1FB38795C9F466C1C01192F75276,
	ProxyElement__ctor_mAFD852231DF0231726E41911409CB2725BE990AC,
	ProxyElement_get_Properties_m8A3EE4A3EEF2571DE4768730CEF4107331490377,
	HttpWebRequestElement__ctor_mE3A4CA43FCC72E10B6C7B4920F429C028765E233,
	HttpWebRequestElement_get_Properties_m531EDF2F56823100C47A9EEE1575143E5EB5463C,
	Ipv6Element__ctor_m3F7DF39E6E51517E1429BAE43FA782BF3AF17965,
	Ipv6Element_get_Properties_m156008D7E5279C50DE4CEDB6D4D3CEDAF2ACF8DC,
	NetSectionGroup__ctor_m566D7C9466957BCE3B8FE2D0EA2582CC2F95F269,
	SettingsSection__ctor_mC5F3D29EDC94D87B0B0542DE3702795441AC3005,
	SettingsSection_get_Properties_m1ABB76DEC7441CFEDD4E7EDF99B8F5C258101254,
	PerformanceCountersElement__ctor_m5A090222699B48BEB5FCC743198613FA8D081083,
	PerformanceCountersElement_get_Properties_m3C7B73AC6E5F5E92426D7DC091A2ECE5CFCD9FD0,
	ServicePointManagerElement__ctor_m61B031714F8498D467B5A0958EE62F73E0C58EB7,
	ServicePointManagerElement_get_Properties_mC1C586246B4FE10AC90622A0CC6A5936D501B677,
	SocketElement__ctor_m428B7094399223FFB9A5B62BF9D8CEA18A00A4C3,
	SocketElement_get_Properties_m9CF8E9B1A9B41B7EC24A4F91CE2E8ECBF317426A,
	WebProxyScriptElement__ctor_mC8AF875E80D96B18AA387148009AE1C630D83591,
	WebProxyScriptElement_get_Properties_m8AD25399F804B2D22BC8312102EBC28A0CAE6E26,
	WebRequestModulesSection__ctor_m0CAB6F207E3B29D65AEA38A6AC191873E3000F02,
	WebRequestModulesSection_get_Properties_m909A3E4C4A61BFCC9D09F397D9314E5F74F3FE44,
	WebRequestModuleElementCollection__ctor_m8B880B0EAE7CEF1CB79CD264A9B6D62AB6A22961,
	DiagnosticsConfigurationHandler__ctor_m185BC74B0225A3E16EEB4164923931B79AAA0CF0,
	DiagnosticsConfigurationHandler_Create_mCC7EF5B43B6913E2429B37EC5923202EBB20AA96,
	ThrowStub_ThrowNotSupportedException_mF1DE187697F740D8C18B8966BBEB276878CD86FD,
};
static const int32_t s_InvokerIndices[346] = 
{
	1,
	2,
	0,
	1003,
	1004,
	1005,
	1006,
	114,
	114,
	114,
	142,
	14,
	114,
	94,
	114,
	1007,
	9,
	114,
	23,
	212,
	377,
	377,
	1008,
	1008,
	14,
	23,
	31,
	26,
	43,
	171,
	171,
	171,
	94,
	4,
	3,
	10,
	114,
	14,
	114,
	48,
	48,
	203,
	10,
	14,
	111,
	9,
	1009,
	14,
	10,
	850,
	172,
	23,
	1010,
	23,
	160,
	34,
	160,
	1011,
	34,
	23,
	1012,
	1013,
	1014,
	1015,
	1016,
	1017,
	1018,
	1019,
	1020,
	1021,
	1022,
	1023,
	95,
	48,
	48,
	48,
	48,
	1024,
	1025,
	764,
	9,
	9,
	9,
	364,
	160,
	0,
	59,
	854,
	1026,
	34,
	160,
	3,
	23,
	23,
	23,
	26,
	171,
	171,
	1027,
	1028,
	1029,
	1030,
	1031,
	1032,
	1033,
	48,
	48,
	48,
	48,
	3,
	14,
	10,
	14,
	575,
	54,
	49,
	3,
	10,
	30,
	30,
	30,
	52,
	32,
	0,
	114,
	14,
	575,
	54,
	35,
	1034,
	1035,
	1035,
	1036,
	1036,
	209,
	342,
	1037,
	1036,
	1038,
	1038,
	1034,
	526,
	1039,
	1040,
	1041,
	1042,
	1042,
	1043,
	88,
	1044,
	334,
	1045,
	336,
	1046,
	1034,
	1047,
	102,
	26,
	177,
	26,
	23,
	118,
	23,
	278,
	142,
	142,
	23,
	3,
	23,
	23,
	23,
	23,
	23,
	32,
	9,
	10,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	9,
	10,
	3,
	23,
	32,
	62,
	171,
	171,
	43,
	3,
	3,
	23,
	26,
	307,
	27,
	26,
	14,
	26,
	23,
	116,
	34,
	10,
	14,
	136,
	26,
	14,
	114,
	23,
	164,
	164,
	23,
	26,
	14,
	26,
	26,
	317,
	317,
	317,
	317,
	317,
	317,
	317,
	317,
	1048,
	1048,
	14,
	14,
	14,
	3,
	23,
	396,
	1049,
	114,
	114,
	10,
	26,
	116,
	14,
	317,
	396,
	26,
	116,
	317,
	23,
	114,
	31,
	26,
	28,
	23,
	396,
	579,
	10,
	26,
	37,
	116,
	14,
	317,
	23,
	396,
	396,
	396,
	396,
	307,
	14,
	26,
	48,
	210,
	0,
	116,
	14,
	317,
	23,
	172,
	141,
	32,
	142,
	14,
	418,
	9,
	10,
	3,
	141,
	208,
	10,
	114,
	114,
	14,
	131,
	23,
	32,
	171,
	14,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	95,
	23,
	23,
	23,
	14,
	23,
	14,
	26,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	23,
	177,
	3,
};
static const Il2CppTokenRangePair s_rgctxIndices[2] = 
{
	{ 0x02000049, { 0, 6 } },
	{ 0x0200004A, { 6, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[9] = 
{
	{ (Il2CppRGCTXDataType)3, 9342 },
	{ (Il2CppRGCTXDataType)2, 13488 },
	{ (Il2CppRGCTXDataType)3, 9343 },
	{ (Il2CppRGCTXDataType)3, 9344 },
	{ (Il2CppRGCTXDataType)3, 9345 },
	{ (Il2CppRGCTXDataType)3, 9346 },
	{ (Il2CppRGCTXDataType)3, 9347 },
	{ (Il2CppRGCTXDataType)3, 9348 },
	{ (Il2CppRGCTXDataType)2, 10709 },
};
extern const Il2CppCodeGenModule g_SystemCodeGenModule;
const Il2CppCodeGenModule g_SystemCodeGenModule = 
{
	"System.dll",
	346,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	2,
	s_rgctxIndices,
	9,
	s_rgctxValues,
	NULL,
};
