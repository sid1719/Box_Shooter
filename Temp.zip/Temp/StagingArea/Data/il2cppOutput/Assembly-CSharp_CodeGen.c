﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void Controller::Start()
extern void Controller_Start_mD822F399A5279EF3FB533029C3E5CB12B6A077C9 ();
// 0x00000002 System.Void Controller::Update()
extern void Controller_Update_mD48924026D2AE451BB2B47FA0E23043A13A76E82 ();
// 0x00000003 System.Void Controller::.ctor()
extern void Controller__ctor_m8ECC1060F6835885E4EB6486F5494BBBCDD17B3A ();
// 0x00000004 System.Void GameManager::Start()
extern void GameManager_Start_mD77CCDBF1DA8EC5C3AE7ED955DE4E7F54B79C88E ();
// 0x00000005 System.Void GameManager::Update()
extern void GameManager_Update_m07DC32583BF09EB71183725B7B95FA7B4716988A ();
// 0x00000006 System.Void GameManager::EndGame()
extern void GameManager_EndGame_mCF189CFE362687385C62B3CE6294CF48C34A7269 ();
// 0x00000007 System.Void GameManager::BeatLevel()
extern void GameManager_BeatLevel_m7140C4A59E65AC27C25787D4E460E5373F17B73F ();
// 0x00000008 System.Void GameManager::targetHit(System.Int32,System.Single)
extern void GameManager_targetHit_m56A146E4B0225A9315E505BA7A43DB3B783F6615 ();
// 0x00000009 System.Void GameManager::RestartGame()
extern void GameManager_RestartGame_m1503EDBB7CBD522A762D8B37114E7AC96659FA86 ();
// 0x0000000A System.Void GameManager::NextLevel()
extern void GameManager_NextLevel_mF6C956ECA09992B9D36B913E2273B39C076B71F2 ();
// 0x0000000B System.Void GameManager::.ctor()
extern void GameManager__ctor_mF7F1107D38DE91EB8A57C1C3BB1A932C50CD9693 ();
// 0x0000000C System.Void MouseLooker::Start()
extern void MouseLooker_Start_mC4EE75FAF783F8E3CC70EE056AFAEBCB4D3A5C13 ();
// 0x0000000D System.Void MouseLooker::Update()
extern void MouseLooker_Update_m522ECE5D18C7C696076F1F74C7308378BD1D580D ();
// 0x0000000E System.Void MouseLooker::LockCursor(System.Boolean)
extern void MouseLooker_LockCursor_m68B49AE43A0E7DD25A9D7AA063878A52F7388850 ();
// 0x0000000F System.Void MouseLooker::LookRotation()
extern void MouseLooker_LookRotation_m929A81D27C66B3018CE064BDDE0C20D2C69D1E16 ();
// 0x00000010 UnityEngine.Quaternion MouseLooker::ClampRotationAroundXAxis(UnityEngine.Quaternion)
extern void MouseLooker_ClampRotationAroundXAxis_m4ECFEFCA674C7D2924D4BB70A0E9C9E04697F94E ();
// 0x00000011 System.Void MouseLooker::.ctor()
extern void MouseLooker__ctor_m049201CCE60BCC1603381A6D00C4B7F47C4E5280 ();
// 0x00000012 System.Void NextLevel::OnCollisionEnter(UnityEngine.Collision)
extern void NextLevel_OnCollisionEnter_m0C8FD7CDA4726008DD6719F5A6E0E9B422F8B771 ();
// 0x00000013 System.Void NextLevel::.ctor()
extern void NextLevel__ctor_mB6E0B5527063E3A00FC2D7C6A40A94B44F56B079 ();
// 0x00000014 System.Void PlayAgain::OnCollisionEnter(UnityEngine.Collision)
extern void PlayAgain_OnCollisionEnter_m4FE64953825EE5AB576A15246456B5C5D3DEE05D ();
// 0x00000015 System.Void PlayAgain::.ctor()
extern void PlayAgain__ctor_m866DC30F2DD4E2260CF6E2DB49E87BEEEB74375E ();
// 0x00000016 System.Void Rotate::Update()
extern void Rotate_Update_m7EECA0DFF07C6BCA773478F66A949EE038D28330 ();
// 0x00000017 System.Void Rotate::.ctor()
extern void Rotate__ctor_mC70374AA84BC2CA04CA039D1B56F5AF1B95D42CF ();
// 0x00000018 System.Void Shooter::Update()
extern void Shooter_Update_m935A8A73F123E2F5E8EFA76AC538E03F8B042A65 ();
// 0x00000019 System.Void Shooter::.ctor()
extern void Shooter__ctor_m56932B9A82C892AA66136ED9080A7C05C2E86F45 ();
// 0x0000001A System.Void SpawnGameObjects::Start()
extern void SpawnGameObjects_Start_mD3DA6B518E4E6F8F305828CA6ABE3AB53D952A1E ();
// 0x0000001B System.Void SpawnGameObjects::Update()
extern void SpawnGameObjects_Update_mB20D6B170E3E76FE871AFC1E5154618344841F51 ();
// 0x0000001C System.Void SpawnGameObjects::MakeThingToSpawn()
extern void SpawnGameObjects_MakeThingToSpawn_mEB4A804F18F06150B89B0B5186890AA0BEBC23BB ();
// 0x0000001D System.Void SpawnGameObjects::.ctor()
extern void SpawnGameObjects__ctor_m55388C385584F235FC31880B1BBEF6E63198DC1D ();
// 0x0000001E System.Void TargetBehavior::OnCollisionEnter(UnityEngine.Collision)
extern void TargetBehavior_OnCollisionEnter_m6C0235E84BAE78982CC1B07907830C262B5AA22B ();
// 0x0000001F System.Void TargetBehavior::.ctor()
extern void TargetBehavior__ctor_mF4D09BEB9686DE2F9BD4ADD39290068B00F77C04 ();
// 0x00000020 System.Void TargetExit::Start()
extern void TargetExit_Start_m25A9D9AD53CF16C9432F4D75C83573269FEB6859 ();
// 0x00000021 System.Void TargetExit::Update()
extern void TargetExit_Update_mDFEA3D9CC424E2BC84CFFF2E017309353B4B39FE ();
// 0x00000022 System.Void TargetExit::KillTarget()
extern void TargetExit_KillTarget_mA84048FA4263E786CD37B258B65E417C890712C3 ();
// 0x00000023 System.Void TargetExit::.ctor()
extern void TargetExit__ctor_mC5C60B5ACDE91D61BF77ACF00F5F06BB08929C21 ();
// 0x00000024 System.Void TargetMover::Update()
extern void TargetMover_Update_m6B9DA8194CAEC221408A7C2D46BD62E6C3C9A6A9 ();
// 0x00000025 System.Void TargetMover::.ctor()
extern void TargetMover__ctor_m6C02C0DBC4365F09D9E2DF6D2BFE154CD7492382 ();
// 0x00000026 System.Void TimedObjectDestructor::Awake()
extern void TimedObjectDestructor_Awake_mC70D93E7E83C6639F5B8BCA0C7FB703773ABC549 ();
// 0x00000027 System.Void TimedObjectDestructor::DestroyNow()
extern void TimedObjectDestructor_DestroyNow_mB740F03B96102CAAF0D09EB2B97CB013DFE473C4 ();
// 0x00000028 System.Void TimedObjectDestructor::.ctor()
extern void TimedObjectDestructor__ctor_mBEA17C0A35A58722FACE41B032839FCA9F7B5790 ();
// 0x00000029 System.Void basiccontroller::Update()
extern void basiccontroller_Update_mA892099F496DF95C31BA6019057D75D0B10036DC ();
// 0x0000002A System.Void basiccontroller::.ctor()
extern void basiccontroller__ctor_m215445AA3EEC6EA5363FAEABAE2FE655524E62D0 ();
// 0x0000002B System.Void basicmover::Update()
extern void basicmover_Update_mEC6F39FA5CA0D40FD5CB3287E388649F02C4A764 ();
// 0x0000002C System.Void basicmover::.ctor()
extern void basicmover__ctor_mDF6ABCBD7F36A9E439010A744DF1354071065C59 ();
static Il2CppMethodPointer s_methodPointers[44] = 
{
	Controller_Start_mD822F399A5279EF3FB533029C3E5CB12B6A077C9,
	Controller_Update_mD48924026D2AE451BB2B47FA0E23043A13A76E82,
	Controller__ctor_m8ECC1060F6835885E4EB6486F5494BBBCDD17B3A,
	GameManager_Start_mD77CCDBF1DA8EC5C3AE7ED955DE4E7F54B79C88E,
	GameManager_Update_m07DC32583BF09EB71183725B7B95FA7B4716988A,
	GameManager_EndGame_mCF189CFE362687385C62B3CE6294CF48C34A7269,
	GameManager_BeatLevel_m7140C4A59E65AC27C25787D4E460E5373F17B73F,
	GameManager_targetHit_m56A146E4B0225A9315E505BA7A43DB3B783F6615,
	GameManager_RestartGame_m1503EDBB7CBD522A762D8B37114E7AC96659FA86,
	GameManager_NextLevel_mF6C956ECA09992B9D36B913E2273B39C076B71F2,
	GameManager__ctor_mF7F1107D38DE91EB8A57C1C3BB1A932C50CD9693,
	MouseLooker_Start_mC4EE75FAF783F8E3CC70EE056AFAEBCB4D3A5C13,
	MouseLooker_Update_m522ECE5D18C7C696076F1F74C7308378BD1D580D,
	MouseLooker_LockCursor_m68B49AE43A0E7DD25A9D7AA063878A52F7388850,
	MouseLooker_LookRotation_m929A81D27C66B3018CE064BDDE0C20D2C69D1E16,
	MouseLooker_ClampRotationAroundXAxis_m4ECFEFCA674C7D2924D4BB70A0E9C9E04697F94E,
	MouseLooker__ctor_m049201CCE60BCC1603381A6D00C4B7F47C4E5280,
	NextLevel_OnCollisionEnter_m0C8FD7CDA4726008DD6719F5A6E0E9B422F8B771,
	NextLevel__ctor_mB6E0B5527063E3A00FC2D7C6A40A94B44F56B079,
	PlayAgain_OnCollisionEnter_m4FE64953825EE5AB576A15246456B5C5D3DEE05D,
	PlayAgain__ctor_m866DC30F2DD4E2260CF6E2DB49E87BEEEB74375E,
	Rotate_Update_m7EECA0DFF07C6BCA773478F66A949EE038D28330,
	Rotate__ctor_mC70374AA84BC2CA04CA039D1B56F5AF1B95D42CF,
	Shooter_Update_m935A8A73F123E2F5E8EFA76AC538E03F8B042A65,
	Shooter__ctor_m56932B9A82C892AA66136ED9080A7C05C2E86F45,
	SpawnGameObjects_Start_mD3DA6B518E4E6F8F305828CA6ABE3AB53D952A1E,
	SpawnGameObjects_Update_mB20D6B170E3E76FE871AFC1E5154618344841F51,
	SpawnGameObjects_MakeThingToSpawn_mEB4A804F18F06150B89B0B5186890AA0BEBC23BB,
	SpawnGameObjects__ctor_m55388C385584F235FC31880B1BBEF6E63198DC1D,
	TargetBehavior_OnCollisionEnter_m6C0235E84BAE78982CC1B07907830C262B5AA22B,
	TargetBehavior__ctor_mF4D09BEB9686DE2F9BD4ADD39290068B00F77C04,
	TargetExit_Start_m25A9D9AD53CF16C9432F4D75C83573269FEB6859,
	TargetExit_Update_mDFEA3D9CC424E2BC84CFFF2E017309353B4B39FE,
	TargetExit_KillTarget_mA84048FA4263E786CD37B258B65E417C890712C3,
	TargetExit__ctor_mC5C60B5ACDE91D61BF77ACF00F5F06BB08929C21,
	TargetMover_Update_m6B9DA8194CAEC221408A7C2D46BD62E6C3C9A6A9,
	TargetMover__ctor_m6C02C0DBC4365F09D9E2DF6D2BFE154CD7492382,
	TimedObjectDestructor_Awake_mC70D93E7E83C6639F5B8BCA0C7FB703773ABC549,
	TimedObjectDestructor_DestroyNow_mB740F03B96102CAAF0D09EB2B97CB013DFE473C4,
	TimedObjectDestructor__ctor_mBEA17C0A35A58722FACE41B032839FCA9F7B5790,
	basiccontroller_Update_mA892099F496DF95C31BA6019057D75D0B10036DC,
	basiccontroller__ctor_m215445AA3EEC6EA5363FAEABAE2FE655524E62D0,
	basicmover_Update_mEC6F39FA5CA0D40FD5CB3287E388649F02C4A764,
	basicmover__ctor_mDF6ABCBD7F36A9E439010A744DF1354071065C59,
};
static const int32_t s_InvokerIndices[44] = 
{
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	921,
	23,
	23,
	23,
	23,
	23,
	31,
	23,
	1503,
	23,
	26,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	44,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
